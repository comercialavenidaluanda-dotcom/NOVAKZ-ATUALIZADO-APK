# ==============================================================================
# NOVA KZ — Production ProGuard & R8 Optimization Rules
# Application ID: ao.novakz.app
# ==============================================================================

# 1. Room Database & SQLite
-keepclassmembers class * extends androidx.room.RoomDatabase {
    public <init>();
}
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Dao interface * { *; }
-keep @androidx.room.Entity class * { *; }
-keep class * extends androidx.room.migration.Migration { *; }
-dontwarn androidx.room.paging.**

# 2. Domain Models, Entities & JSON Serialization (Moshi)
-keep class com.example.domain.models.** { *; }
-keep class com.example.data.local.** { *; }
-keep class com.example.network.** { *; }
-keepclassmembers class com.example.domain.models.** {
    <fields>;
    <methods>;
}
-keepclassmembers enum com.example.domain.models.** { *; }
-keepclassmembers enum com.example.domain.models.PaymentStatus { *; }
-keepclassmembers enum com.example.domain.models.PaymentType { *; }
-keepclassmembers enum com.example.domain.models.AuthMethod { *; }
-keepclassmembers enum com.example.domain.models.CardStatus { *; }

-keepclasseswithmembers class * {
    @com.squareup.moshi.* <methods>;
}
-keepclasseswithmembers class * {
    @com.squareup.moshi.* <fields>;
}
-keep class com.squareup.moshi.** { *; }
-dontwarn com.squareup.moshi.**

# 3. Attributes for Reflection & Type Annotations
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# 4. OkHttp & Networking
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# 5. Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# 6. Biometric Authentication & AndroidX Security
-keep class androidx.biometric.** { *; }
-keep class androidx.security.crypto.** { *; }
-dontwarn androidx.security.crypto.**

# 7. Firebase Cloud Messaging & Google Play Services
-keep class com.google.firebase.** { *; }
-keep class com.example.notifications.NovaKzFirebaseMessagingService { *; }
-dontwarn com.google.firebase.**

# 8. Jetpack Navigation & Deep Links
-keep class androidx.navigation.** { *; }
-keep class androidx.compose.material3.** { *; }

