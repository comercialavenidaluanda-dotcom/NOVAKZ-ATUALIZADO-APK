package com.example.network

import com.example.BuildConfig
import com.example.core.security.NovaLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

open class SupabaseRestClient(
    private val baseUrl: String = SupabaseEndpoints.PROJECT_URL,
    private val getRefreshToken: () -> String? = { null },
    private val onTokensRefreshed: ((accessToken: String, refreshToken: String?, expiresInSeconds: Long) -> Unit)? = null,
    private val getAuthToken: () -> String? = { null }
) {
    /**
     * Optional interceptor for deterministic unit/Robolectric testing of Supabase RPCs.
     * In production this is always null, so all calls hit the live Supabase PostgREST endpoint.
     */
    var rpcHandler: (suspend (functionName: String, params: JSONObject) -> NetworkResult<String>?)? = null
    private val refreshLock = Any()
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    val anonKey: String
        get() {
            return try {
                val key = BuildConfig.SUPABASE_ANON_KEY
                if (key.isNullOrBlank() || key.contains("placeholder_anon_key") || key == "NOT_CONFIGURED") "" else key
            } catch (e: Exception) {
                ""
            }
        }

    fun isConfigured(): Boolean {
        return rpcHandler != null || anonKey.isNotBlank()
    }

    suspend fun signInWithPassword(email: String, password: String): NetworkResult<JSONObject> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente. Defina a SUPABASE_ANON_KEY no painel de segredos para autenticação real.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/auth/v1/token?grant_type=password"
            val payload = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            executeRequest(request).map { raw ->
                JSONObject(raw)
            }
        }
    }

    suspend fun signUpWithPassword(email: String, password: String, metadata: Map<String, Any> = emptyMap()): NetworkResult<JSONObject> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente. Defina a SUPABASE_ANON_KEY no painel de segredos para registrar utilizadores.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/auth/v1/signup"
            val payload = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
                if (metadata.isNotEmpty()) {
                    put("data", JSONObject(metadata))
                }
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            executeRequest(request).map { raw ->
                JSONObject(raw)
            }
        }
    }

    suspend fun resetPasswordForEmail(email: String): NetworkResult<String> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente. Defina a SUPABASE_ANON_KEY no painel de segredos.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/auth/v1/recover"
            val payload = JSONObject().apply {
                put("email", email.trim())
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            executeRequest(request)
        }
    }

    open suspend fun invokeRpc(functionName: String, params: JSONObject): NetworkResult<String> {
        rpcHandler?.let { handler ->
            val intercepted = handler(functionName, params)
            if (intercepted != null) {
                return intercepted
            }
        }
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente. Defina a SUPABASE_ANON_KEY no painel de segredos para conexão ao backend.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/rpc/$functionName"
            val token = resolveBearerToken()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .post(params.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun invokeEdgeGateway(action: String, payload: JSONObject): NetworkResult<String> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente. Defina a SUPABASE_ANON_KEY no painel de segredos para conexão ao backend.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/functions/v1/${SupabaseEndpoints.EDGE_INTEGRATION_GATEWAY}"
            val token = resolveBearerToken()

            val fullBody = JSONObject().apply {
                put("action", action)
                put("environment", "SANDBOX")
                put("payload", payload)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .post(fullBody.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun upsertDeviceToken(
        userId: String,
        token: String,
        platform: String = "android"
    ): NetworkResult<String> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/${SupabaseEndpoints.TABLE_DEVICE_TOKENS}"
            val authToken = resolveBearerToken()

            val record = JSONObject().apply {
                put("user_id", userId)
                put("token", token)
                put("platform", platform)
                put("last_seen_at", java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date()))
                put("is_active", true)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Prefer", "resolution=merge-duplicates")
                .addHeader("Content-Type", "application/json")
                .post(record.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun deactivateDeviceToken(token: String): NetworkResult<String> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/${SupabaseEndpoints.TABLE_DEVICE_TOKENS}?token=eq.$token"
            val authToken = resolveBearerToken()

            val update = JSONObject().apply {
                put("is_active", false)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Content-Type", "application/json")
                .patch(update.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun queryLegalAcceptance(userId: String): NetworkResult<String> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/${SupabaseEndpoints.TABLE_LEGAL_ACCEPTANCES}?user_id=eq.$userId&order=accepted_at.desc&limit=1"
            val authToken = resolveBearerToken()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Accept", "application/json")
                .get()
                .build()

            executeRequest(request)
        }
    }

    suspend fun recordLegalAcceptance(
        userId: String,
        termsVersion: String,
        privacyVersion: String,
        acceptedTerms: Boolean,
        acceptedPrivacy: Boolean
    ): NetworkResult<String> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/${SupabaseEndpoints.TABLE_LEGAL_ACCEPTANCES}"
            val authToken = resolveBearerToken()

            val isoDate = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
                timeZone = java.util.TimeZone.getTimeZone("UTC")
            }.format(java.util.Date())

            val payload = JSONObject().apply {
                put("user_id", userId)
                put("terms_version", termsVersion)
                put("privacy_version", privacyVersion)
                put("accepted_terms", acceptedTerms)
                put("accepted_privacy", acceptedPrivacy)
                put("accepted_at", isoDate)
                put("created_at", isoDate)
                put("updated_at", isoDate)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Prefer", "resolution=merge-duplicates")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun requestAccountDeletion(
        reason: String = "user_requested",
        userEmail: String? = null,
        userId: String? = null
    ): NetworkResult<String> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente. Defina a SUPABASE_ANON_KEY no painel de segredos.", code = 503)
        }
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/functions/v1/${SupabaseEndpoints.EDGE_ACCOUNT_DELETION}"
            val authToken = resolveBearerToken()

            val payload = JSONObject().apply {
                put("action", "request_deletion")
                put("reason", reason)
                put("confirmation", true)
                put("status", "REQUESTED")
                put("email", userEmail?.ifBlank { null } ?: "comercialavenidaluanda@gmail.com")
                if (!userId.isNullOrBlank()) {
                    put("user_id", userId)
                }
                put("timestamp", System.currentTimeMillis())
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    fun refreshSessionSync(currentRefreshToken: String? = getRefreshToken()): NetworkResult<JSONObject> {
        if (!isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente.", code = 503)
        }
        val tokenToUse = currentRefreshToken?.trim().orEmpty()
        if (tokenToUse.isBlank() || tokenToUse.startsWith("nkz_sandbox_")) {
            return NetworkResult.Error("Sessão sem refresh token válido.", code = 401, isSessionExpired = true)
        }
        synchronized(refreshLock) {
            return try {
                val url = "$baseUrl/auth/v1/token?grant_type=refresh_token"
                val payload = JSONObject().apply {
                    put("refresh_token", tokenToUse)
                }
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", anonKey)
                    .addHeader("Content-Type", "application/json")
                    .post(payload.toString().toRequestBody(jsonMediaType))
                    .build()

                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful && body.isNotBlank()) {
                        val json = JSONObject(body)
                        val newAccess = json.optString("access_token", "")
                        val newRefresh = json.optString("refresh_token", tokenToUse)
                        val expiresIn = json.optLong("expires_in", 3600L)
                        if (newAccess.isNotBlank()) {
                            onTokensRefreshed?.invoke(newAccess, newRefresh, expiresIn)
                            NetworkResult.Success(json)
                        } else {
                            NetworkResult.Error("Resposta de refresh inválida.", code = 401, isSessionExpired = true)
                        }
                    } else {
                        NetworkResult.Error("Refresh token expirado ou revogado.", code = response.code, isSessionExpired = true)
                    }
                }
            } catch (e: Exception) {
                NetworkResult.Error("Falha de rede ao renovar sessão: ${e.localizedMessage}", isNetworkError = true, cause = e)
            }
        }
    }

    suspend fun refreshSession(currentRefreshToken: String? = getRefreshToken()): NetworkResult<JSONObject> {
        return withContext(Dispatchers.IO) {
            refreshSessionSync(currentRefreshToken)
        }
    }

    private fun resolveBearerToken(): String {
        val raw = getAuthToken()
        // Never send a local synthetic nkz_sandbox_token_* as a Supabase JWT to remote REST endpoints
        return if (raw.isNullOrBlank() || raw.startsWith("nkz_sandbox_token_")) {
            anonKey
        } else {
            raw
        }
    }

    private fun executeRequest(request: Request, allowRefreshRetry: Boolean = true): NetworkResult<String> {
        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val code = response.code

                when {
                    response.isSuccessful -> {
                        NetworkResult.Success(body)
                    }
                    code == 401 -> {
                        val isAuthEndpoint = request.url.encodedPath.contains("/auth/v1/")
                        if (allowRefreshRetry && !isAuthEndpoint) {
                            val refresh = getRefreshToken()
                            if (!refresh.isNullOrBlank() && !refresh.startsWith("nkz_sandbox_")) {
                                NovaLogger.i(TAG, "Received 401, attempting automatic token refresh before failing...")
                                val refreshRes = refreshSessionSync(refresh)
                                if (refreshRes is NetworkResult.Success) {
                                    val newAccess = refreshRes.data.optString("access_token", "")
                                    if (newAccess.isNotBlank()) {
                                        val retriedRequest = request.newBuilder()
                                            .header("Authorization", "Bearer $newAccess")
                                            .build()
                                        return executeRequest(retriedRequest, allowRefreshRetry = false)
                                    }
                                }
                            }
                        }
                        NovaLogger.w(TAG, "Session expired or unauthorized ($code)")
                        val friendly = if (isAuthEndpoint) {
                            parsePostgreSqlError(code, body, defaultMessage = "Credenciais inválidas. Verifique o seu e-mail e palavra-passe.")
                        } else {
                            "Sessão expirada. Por favor, volte a autenticar-se."
                        }
                        NetworkResult.Error(friendly, code = 401, isSessionExpired = !isAuthEndpoint)
                    }
                    code == 403 -> {
                        val friendly = parsePostgreSqlError(code, body, defaultMessage = "Acesso não autorizado. Não tem permissão para executar esta ação.")
                        NetworkResult.Error(friendly, code = 403)
                    }
                    code == 404 -> {
                        val friendly = parsePostgreSqlError(code, body, defaultMessage = "Recurso ou serviço não encontrado no servidor NOVA KZ.")
                        NetworkResult.Error(friendly, code = 404)
                    }
                    code == 409 -> {
                        val friendly = parsePostgreSqlError(code, body, defaultMessage = "Conflito na operação. Esta ação já foi registada ou já existe um registo equivalente.")
                        NetworkResult.Error(friendly, code = 409)
                    }
                    code == 422 -> {
                        val friendly = parsePostgreSqlError(code, body, defaultMessage = "Dados não processáveis. Verifique as informações fornecidas.")
                        NetworkResult.Error(friendly, code = 422)
                    }
                    code == 429 -> {
                        NetworkResult.Error("Muitos pedidos seguidos. Por favor, aguarde alguns instantes antes de tentar novamente.", code = 429)
                    }
                    code in 500..599 -> {
                        NovaLogger.e(TAG, "Server error $code")
                        NetworkResult.Error("Serviço temporariamente indisponível ($code). Por favor, tente novamente mais tarde.", code = code)
                    }
                    else -> {
                        val friendly = parsePostgreSqlError(code, body, defaultMessage = "Não foi possível concluir o pedido ($code).")
                        NetworkResult.Error(friendly, code = code)
                    }
                }
            }
        } catch (e: SocketTimeoutException) {
            NovaLogger.e(TAG, "Request timeout", e)
            NetworkResult.Error("Tempo limite excedido. Não foi possível concluir a operação. Verifica a ligação e tenta novamente.", isTimeout = true, cause = e)
        } catch (e: IOException) {
            NovaLogger.e(TAG, "Network IO error", e)
            NetworkResult.Error("Falha de rede ao contactar o servidor NOVA KZ. Verifica a tua ligação à internet e tenta novamente.", isNetworkError = true, cause = e)
        } catch (e: Exception) {
            NovaLogger.e(TAG, "Unexpected error", e)
            NetworkResult.Error(e.localizedMessage ?: "Erro inesperado na comunicação", cause = e)
        }
    }

    private fun parsePostgreSqlError(httpCode: Int, responseBody: String, defaultMessage: String): String {
        if (responseBody.isBlank()) return defaultMessage

        try {
            val json = JSONObject(responseBody)
            val sqlState = json.optString("code", "")
            val rawMsg = json.optString("message", json.optString("msg", json.optString("error_description", "")))

            // 1. PostgreSQL SQLSTATE Code mapping
            when (sqlState) {
                "42501" -> return "Não tens autorização para executar esta operação."
                "23505" -> return "Esta operação ou registo já existe no sistema (duplicação evitada)."
                "23503" -> return "Registo associado não encontrado."
                "22P02" -> return "Formato de dados inválido fornecido ao sistema."
                "P0001" -> {
                    // Custom business exceptions raised in PL/pgSQL
                    val mappedRpcMessage = mapKnownRpcMessage(rawMsg)
                    if (mappedRpcMessage != null) return mappedRpcMessage
                }
            }

            // 2. Map known application/RPC tokens
            val mappedToken = mapKnownRpcMessage(rawMsg)
            if (mappedToken != null) return mappedToken

            // 3. Check for auth error code
            val authErrorCode = json.optString("error_code", "")
            if (authErrorCode.isNotBlank()) {
                when (authErrorCode) {
                    "invalid_credentials" -> return "E-mail ou palavra-passe incorretos."
                    "user_not_found" -> return "Conta de utilizador não encontrada."
                    "email_exists" -> return "Já existe uma conta registada com este endereço de e-mail."
                    "email_address_invalid" -> return "Endereço de e-mail com formato inválido."
                    "over_request_rate_limit" -> return "Limite de tentativas excedido. Tente novamente mais tarde."
                }
            }

            // 4. Sanitize to prevent SQL, table names or stack traces leaking
            if (isTechnicalSqlLeak(rawMsg)) {
                return defaultMessage
            }

            if (rawMsg.isNotBlank() && rawMsg.length < 200) {
                return rawMsg
            }
        } catch (e: Exception) {
            // Not a JSON object or malformed, fallback to safe default
        }

        return defaultMessage
    }

    private fun mapKnownRpcMessage(msg: String): String? {
        val trimmed = msg.trim()
        return when {
            trimmed.contains("RECIPIENT_NOT_FOUND", ignoreCase = true) ->
                "Não encontramos uma conta NOVA associada a este número."
            trimmed.contains("SELF_TRANSFER_NOT_ALLOWED", ignoreCase = true) ->
                "Não podes enviar dinheiro para o teu próprio número."
            trimmed.contains("INSUFFICIENT_FUNDS", ignoreCase = true) ->
                "Saldo insuficiente para concluir esta transferência."
            trimmed.contains("AUTH_REQUIRED", ignoreCase = true) ->
                "A tua sessão expirou. Inicia sessão novamente."
            trimmed.contains("INVALID_AMOUNT", ignoreCase = true) ->
                "Introduz um valor válido superior a zero."
            trimmed.contains("INVALID_IDEMPOTENCY_KEY", ignoreCase = true) ->
                "Chave de idempotência inválida. Tente novamente."
            trimmed.contains("SENDER_WALLET_NOT_FOUND", ignoreCase = true) ->
                "Carteira do remetente não encontrada."
            trimmed.contains("WALLET_NOT_FOUND", ignoreCase = true) ->
                "Carteira da conta não encontrada."
            trimmed.contains("OPERATION_ALREADY_EXISTS", ignoreCase = true) ->
                "Esta operação já foi registada anteriormente."
            trimmed.contains("DUPLICATE_OPERATION", ignoreCase = true) ->
                "Operação duplicada evitada com sucesso."
            else -> null
        }
    }

    private fun isTechnicalSqlLeak(msg: String): Boolean {
        val lower = msg.lowercase()
        return lower.contains("syntax error at or near") ||
                lower.contains("relation \"") ||
                lower.contains("column \"") ||
                lower.contains("null value in column") ||
                lower.contains("function ") && lower.contains("does not exist") ||
                lower.contains("pg_catalog") ||
                lower.contains("select ") ||
                lower.contains("update ") ||
                lower.contains("insert into ") ||
                lower.contains("delete from ") ||
                lower.contains("plpgsql")
    }

    companion object {
        private const val TAG = "SupabaseRestClient"
    }
}
