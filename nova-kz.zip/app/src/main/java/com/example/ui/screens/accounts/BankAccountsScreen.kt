package com.example.ui.screens.accounts

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.BankAccount
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun BankAccountsScreen(
    paymentManager: PaymentManager,
    onBack: () -> Unit
) {
    val accounts by paymentManager.bankAccounts.collectAsState()
    val activeAccounts = accounts.filter { it.isActive }
    val context = LocalContext.current

    var showAddForm by remember { mutableStateOf(false) }
    var newBankName by remember { mutableStateOf("Banco Angolano de Investimentos (BAI)") }
    var newIban by remember { mutableStateOf("AO06.0040.0000.1234.5678.9012.3") }
    var newAccountNumber by remember { mutableStateOf("12345678901") }
    var newAccountType by remember { mutableStateOf("Conta Corrente") }
    var formError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Contas Bancárias",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SandboxDisclaimerBanner()
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Contas Bancárias Vinculadas",
                            color = NovaTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Consulte, adicione, selecione a conta principal ou desative contas vinculadas ao seu perfil.",
                            color = NovaTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(NovaGold)
                            .clickable {
                                showAddForm = !showAddForm
                                formError = null
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("bank_accounts_toggle_add_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Adicionar Conta",
                                tint = NovaNavyDark,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (showAddForm) "Fechar" else "Adicionar",
                                color = NovaNavyDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            if (showAddForm) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bank_account_add_form_card"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaGold, RoundedCornerShape(14.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Associar Nova Conta Bancária",
                                color = NovaGold,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = newBankName,
                                onValueChange = { newBankName = it; formError = null },
                                label = { Text("Instituição Bancária", color = NovaTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NovaGold,
                                    unfocusedBorderColor = NovaNavyCardBorder,
                                    focusedTextColor = NovaTextPrimary,
                                    unfocusedTextColor = NovaTextPrimary
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("add_bank_name_input")
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newIban,
                                onValueChange = { newIban = it; formError = null },
                                label = { Text("IBAN (AO06...)", color = NovaTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NovaGold,
                                    unfocusedBorderColor = NovaNavyCardBorder,
                                    focusedTextColor = NovaTextPrimary,
                                    unfocusedTextColor = NovaTextPrimary
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("add_bank_iban_input")
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = newAccountNumber,
                                onValueChange = { newAccountNumber = it; formError = null },
                                label = { Text("Número de Conta", color = NovaTextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NovaGold,
                                    unfocusedBorderColor = NovaNavyCardBorder,
                                    focusedTextColor = NovaTextPrimary,
                                    unfocusedTextColor = NovaTextPrimary
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("add_bank_account_number_input")
                            )
                            if (formError != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(text = formError!!, color = NovaDangerRed, fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            NovaButton(
                                text = "Guardar Conta Bancária",
                                onClick = {
                                    when (val res = paymentManager.addBankAccount(
                                        bankName = newBankName,
                                        iban = newIban,
                                        accountNumber = newAccountNumber,
                                        accountType = newAccountType
                                    )) {
                                        is NetworkResult.Success -> {
                                            showAddForm = false
                                            formError = null
                                        }
                                        is NetworkResult.Error -> {
                                            formError = res.message
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "add_bank_submit_button"
                            )
                        }
                    }
                }
            }

            items(activeAccounts) { account ->
                BankAccountCard(
                    account = account,
                    onCopyIban = { iban ->
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("IBAN", iban))
                        Toast.makeText(context, "IBAN copiado!", Toast.LENGTH_SHORT).show()
                    },
                    onSetPrimary = {
                        paymentManager.setPrimaryBankAccount(account.id)
                    },
                    onDeactivate = {
                        paymentManager.deactivateBankAccount(account.id)
                    }
                )
            }
        }
    }
}

@Composable
fun BankAccountCard(
    account: BankAccount,
    onCopyIban: (String) -> Unit,
    onSetPrimary: () -> Unit = {},
    onDeactivate: () -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bank_account_card_${account.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(NovaNavyDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = NovaGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = account.bankName,
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = account.accountType,
                            color = NovaTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                if (account.isPrimary) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NovaEmeraldBg)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Principal",
                            color = NovaEmeraldLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Saldo em Conta:",
                color = NovaTextSecondary,
                fontSize = 11.sp
            )
            Text(
                text = formatAoa(account.balance),
                color = NovaGold,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(12.dp))

            // IBAN Row with Copy
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(NovaNavyDark)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "IBAN Angola", color = NovaTextSecondary, fontSize = 10.sp)
                    Text(
                        text = account.iban,
                        color = NovaTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                IconButton(
                    onClick = { onCopyIban(account.iban) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copiar IBAN",
                        tint = NovaGold,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                if (!account.isPrimary) {
                    Text(
                        text = "Definir Principal",
                        color = NovaGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clickable { onSetPrimary() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("set_primary_account_${account.id}")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = "Desativar",
                    color = NovaDangerRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clickable { onDeactivate() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("deactivate_account_${account.id}")
                )
            }
        }
    }
}
