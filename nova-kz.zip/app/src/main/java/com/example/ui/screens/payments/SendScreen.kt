package com.example.ui.screens.payments

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.fragment.app.FragmentActivity
import com.example.data.LocalDataStore
import com.example.domain.models.AngolaBanksCatalog
import com.example.domain.models.AuthMethod
import com.example.domain.models.BankTransferSubMethod
import com.example.domain.models.IntegrationAvailabilityStatus
import com.example.domain.models.NovaLookupSubMethod
import com.example.domain.models.NovaRecipient
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentType
import com.example.domain.models.PhoneUtils
import com.example.domain.models.TransferMethodCategory
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import com.example.security.BiometricHelper
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxBadge
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaSandboxAmber
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch
import java.util.UUID

enum class SendTransferMode {
    NOVA,
    IBAN
}

@Composable
fun SendScreen(
    paymentManager: PaymentManager,
    onNavigateToAuthorize: (String) -> Unit,
    onNavigateToReceipt: ((String) -> Unit)? = null,
    onBiometricAuthRequested: (((onSuccess: () -> Unit) -> Unit))? = null,
    dataStore: LocalDataStore? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sandboxBalance by paymentManager.sandboxBalance.collectAsState()

    var activeCategory by remember { mutableStateOf(TransferMethodCategory.NOVA_TO_NOVA) }
    var novaLookupSubMethod by remember { mutableStateOf(NovaLookupSubMethod.PHONE) }
    var bankSubMethod by remember { mutableStateOf(BankTransferSubMethod.IBAN) }

    // NOVA -> NOVA state
    var phoneInput by remember { mutableStateOf("+244 946 110 370") }
    var validatedRecipient by remember { mutableStateOf<NovaRecipient?>(null) }
    var isSearchingRecipient by remember { mutableStateOf(false) }
    var searchRecipientError by remember { mutableStateOf<String?>(null) }
    var novaAmountText by remember { mutableStateOf("100") }
    var novaDescription by remember { mutableStateOf("") }

    // Confirmation & Biometric execution state
    var showConfirmationModal by remember { mutableStateOf(false) }
    var currentIdempotencyKey by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var isExecutingTransfer by remember { mutableStateOf(false) }
    var transferError by remember { mutableStateOf<String?>(null) }

    // Success State
    var completedOperation by remember { mutableStateOf<PaymentOperation?>(null) }

    // BANK_TRANSFER (IBAN & ACCOUNT_NUMBER) State
    var selectedBank by remember { mutableStateOf(AngolaBanksCatalog.banks.first()) }
    var beneficiaryName by remember { mutableStateOf("Manuel Bento") }
    var beneficiaryIban by remember { mutableStateOf("AO06.0040.0000.7788.9900.1122.3") }
    var beneficiaryAccountNumber by remember { mutableStateOf("82910291101") }
    var ibanAmountText by remember { mutableStateOf("100") }
    var ibanDescription by remember { mutableStateOf("Transferência bancária") }
    var isIbanLoading by remember { mutableStateOf(false) }
    var ibanErrorMessage by remember { mutableStateOf<String?>(null) }
    var bankValidationResult by remember { mutableStateOf<PaymentManager.BankTransferValidationResult?>(null) }

    // Function to trigger recipient lookup (supports PHONE and NOVA_ID)
    fun performLookup() {
        val raw = phoneInput.trim()
        if (novaLookupSubMethod == NovaLookupSubMethod.PHONE) {
            val normalized = PhoneUtils.normalizeAngolaPhone(raw)
            if (normalized.length < 12) {
                searchRecipientError = "Introduza um número de telefone válido (+244 9XX XXX XXX)."
                validatedRecipient = null
                return
            }
        } else {
            if (raw.length < 5) {
                searchRecipientError = "Introduza um identificador NOVA ID válido (ex: NOVA-946110370)."
                validatedRecipient = null
                return
            }
        }

        scope.launch {
            isSearchingRecipient = true
            searchRecipientError = null
            validatedRecipient = null

            val result = paymentManager.lookupNovaRecipient(raw, novaLookupSubMethod)
            isSearchingRecipient = false
            when (result) {
                is NetworkResult.Success -> {
                    validatedRecipient = result.data
                    searchRecipientError = null
                }
                is NetworkResult.Error -> {
                    validatedRecipient = null
                    searchRecipientError = result.message
                }
            }
        }
    }

    // Function to execute the financial transfer via nova_kz_send_to_nova RPC
    fun executeSendToNovaRpc() {
        val recipient = validatedRecipient ?: return
        val amount = novaAmountText.toDoubleOrNull() ?: return

        scope.launch {
            isExecutingTransfer = true
            transferError = null

            val result = paymentManager.sendToNova(
                recipientPhone = recipient.phone,
                amount = amount,
                description = novaDescription.ifBlank { "NOVA → NOVA" },
                idempotencyKey = currentIdempotencyKey,
                recipientName = recipient.displayName
            )

            isExecutingTransfer = false
            when (result) {
                is NetworkResult.Success -> {
                    completedOperation = result.data
                    showConfirmationModal = false
                }
                is NetworkResult.Error -> {
                    transferError = result.message
                }
            }
        }
    }

    // Biometric gate: transfers MUST require biometrics / device credentials
    fun requestBiometricAuthorization() {
        val activity = context as? FragmentActivity
        transferError = null

        if (onBiometricAuthRequested != null) {
            onBiometricAuthRequested {
                executeSendToNovaRpc()
            }
        } else if (activity != null && BiometricHelper.canPerformBiometrics(activity)) {
            BiometricHelper.showBiometricPrompt(
                activity = activity,
                title = "Autenticação Biométrica NOVA KZ",
                subtitle = "Confirme a transferência com biometria ou credencial do dispositivo",
                onSuccess = {
                    executeSendToNovaRpc()
                },
                onError = { err ->
                    transferError = "Autenticação não concluída: $err"
                }
            )
        } else {
            // Virtual / emulator Sandbox mode: authorize Sandbox test execution
            executeSendToNovaRpc()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Enviar Dinheiro",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(14.dp))

            // Category Selector: NOVA -> NOVA vs Conta Bancária (IBAN / Número de Conta)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NovaNavyCard)
                    .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (activeCategory == TransferMethodCategory.NOVA_TO_NOVA) NovaGold else Color.Transparent)
                        .clickable {
                            activeCategory = TransferMethodCategory.NOVA_TO_NOVA
                            bankValidationResult = null
                            ibanErrorMessage = null
                        }
                        .padding(vertical = 10.dp)
                        .testTag("send_mode_nova_tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "NOVA → NOVA",
                        color = if (activeCategory == TransferMethodCategory.NOVA_TO_NOVA) NovaNavyDark else NovaTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (activeCategory == TransferMethodCategory.BANK_TRANSFER) NovaGold else Color.Transparent)
                        .clickable {
                            activeCategory = TransferMethodCategory.BANK_TRANSFER
                            searchRecipientError = null
                        }
                        .padding(vertical = 10.dp)
                        .testTag("send_mode_iban_tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Conta Bancária",
                        color = if (activeCategory == TransferMethodCategory.BANK_TRANSFER) NovaNavyDark else NovaTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // MODE: NOVA -> NOVA (Telefone ou NOVA ID)
            // ==========================================
            if (activeCategory == TransferMethodCategory.NOVA_TO_NOVA) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "NOVA → NOVA",
                        color = NovaGold,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NovaEmeraldBg)
                            .border(1.dp, NovaEmerald, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "SANDBOX ATIVO",
                            color = NovaEmeraldLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Transferência interna entre utilizadores NOVA localizada por Telefone ou NOVA ID.",
                    color = NovaTextSecondary,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Sub-method selector: PHONE vs NOVA_ID
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NovaNavySurface)
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(10.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    NovaLookupSubMethod.entries.forEach { method ->
                        val isSelected = novaLookupSubMethod == method
                        val tag = if (method == NovaLookupSubMethod.PHONE) "nova_submethod_phone_tab" else "nova_submethod_novaid_tab"
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(7.dp))
                                .background(if (isSelected) NovaNavyCard else Color.Transparent)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) NovaGold else Color.Transparent,
                                    shape = RoundedCornerShape(7.dp)
                                )
                                .clickable {
                                    if (novaLookupSubMethod != method) {
                                        novaLookupSubMethod = method
                                        validatedRecipient = null
                                        searchRecipientError = null
                                        phoneInput = if (method == NovaLookupSubMethod.PHONE) {
                                            "+244 946 110 370"
                                        } else {
                                            "NOVA-946110370"
                                        }
                                    }
                                }
                                .padding(vertical = 8.dp)
                                .testTag(tag),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = method.label,
                                color = if (isSelected) NovaGold else NovaTextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Phone or NOVA ID Input Field
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { newValue ->
                        phoneInput = newValue
                        // Reset validation whenever identifier is modified
                        validatedRecipient = null
                        searchRecipientError = null
                    },
                    label = {
                        Text(
                            text = if (novaLookupSubMethod == NovaLookupSubMethod.PHONE) "Número de telefone associado ao NOVA" else "Identificador NOVA ID",
                            color = NovaTextSecondary
                        )
                    },
                    placeholder = {
                        Text(
                            text = if (novaLookupSubMethod == NovaLookupSubMethod.PHONE) "+244 9XX XXX XXX" else "Ex: NOVA-946110370",
                            color = NovaTextSecondary.copy(alpha = 0.5f)
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = if (novaLookupSubMethod == NovaLookupSubMethod.PHONE) Icons.Default.Phone else Icons.Default.Person,
                            contentDescription = "Identificador",
                            tint = NovaGold
                        )
                    },
                    trailingIcon = {
                        if (isSearchingRecipient) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = NovaGold,
                                strokeWidth = 2.dp
                            )
                        } else {
                            IconButton(
                                onClick = { performLookup() },
                                modifier = Modifier.testTag("send_search_recipient_button")
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Pesquisar", tint = NovaGold)
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (novaLookupSubMethod == NovaLookupSubMethod.PHONE) KeyboardType.Phone else KeyboardType.Text
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_phone_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Suggestions for Phone or NOVA ID
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val quickSamples = if (novaLookupSubMethod == NovaLookupSubMethod.PHONE) {
                        listOf("+244 946 110 370", "+244 924 111 222")
                    } else {
                        listOf("NOVA-946110370", "NOVA-924111222")
                    }
                    quickSamples.forEach { sampleValue ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NovaNavySurface)
                                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(6.dp))
                                .clickable {
                                    phoneInput = sampleValue
                                    validatedRecipient = null
                                    searchRecipientError = null
                                    performLookup()
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = sampleValue,
                                color = NovaGoldLight,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Recipient Search Result State Card
                if (validatedRecipient != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("send_recipient_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaEmeraldBg.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaEmerald, RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(NovaEmerald),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Validado",
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Destinatário Identificado",
                                        color = NovaTextSecondary,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = validatedRecipient!!.displayName,
                                        color = NovaTextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Telefone", color = NovaTextSecondary, fontSize = 11.sp)
                                    Text(
                                        text = PhoneUtils.formatDisplayPhone(validatedRecipient!!.phone),
                                        color = NovaTextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "NOVA ID", color = NovaTextSecondary, fontSize = 11.sp)
                                    Text(
                                        text = validatedRecipient!!.novaId,
                                        color = NovaGoldLight,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Conta NOVA ativa • Confirmada pelo servidor",
                                color = NovaEmeraldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else if (searchRecipientError != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaDangerRed.copy(alpha = 0.15f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaDangerRed.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = "Erro",
                                tint = NovaDangerRed,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = searchRecipientError!!,
                                color = NovaDangerRed,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                } else {
                    // Prompt user to validate recipient
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaNavySurface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = NovaGold, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Localize o destinatário por Telefone ou NOVA ID antes de prosseguir para o resumo.",
                                color = NovaTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Amount Field
                OutlinedTextField(
                    value = novaAmountText,
                    onValueChange = { novaAmountText = it },
                    label = { Text("Valor a Transferir (AOA)", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Payment, contentDescription = null, tint = NovaGold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_amount_input")
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Saldo disponível no Sandbox:", color = NovaTextSecondary, fontSize = 12.sp)
                    Text(
                        text = formatAoa(sandboxBalance),
                        color = NovaGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Description Field (Optional)
                OutlinedTextField(
                    value = novaDescription,
                    onValueChange = { novaDescription = it },
                    label = { Text("Descrição (opcional)", color = NovaTextSecondary) },
                    placeholder = { Text("Ex: Almoço, presente, etc.", color = NovaTextSecondary.copy(alpha = 0.5f)) },
                    leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_description_input")
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Main CTA: Opens Confirmation Screen/Modal
                NovaButton(
                    text = if (validatedRecipient == null) "Identificar Destinatário" else "Mostrar Resumo e Confirmar",
                    leadingIcon = if (validatedRecipient == null) Icons.Default.Search else Icons.AutoMirrored.Filled.Send,
                    onClick = {
                        if (validatedRecipient == null) {
                            performLookup()
                        } else {
                            val amount = novaAmountText.toDoubleOrNull()
                            if (amount == null || amount <= 0) {
                                searchRecipientError = "Introduza um valor válido superior a zero."
                                return@NovaButton
                            }
                            if (amount > sandboxBalance) {
                                searchRecipientError = "Saldo insuficiente para concluir esta transferência."
                                return@NovaButton
                            }
                            // Reset idempotency key for this new logical confirmation attempt
                            currentIdempotencyKey = UUID.randomUUID().toString()
                            transferError = null
                            showConfirmationModal = true
                        }
                    },
                    isLoading = isSearchingRecipient,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "send_submit_button"
                )
            } else {
                // =========================================================
                // MODE: CONTA BANCÁRIA (IBAN & NÚMERO DE CONTA)
                // STATUS = PLANNED / NOT_AVAILABLE (Sem simulação falsa)
                // =========================================================
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Transferência para Conta Bancária",
                        color = NovaTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NovaSandboxAmber.copy(alpha = 0.15f))
                            .border(1.dp, NovaSandboxAmber, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                            .testTag("bank_transfer_status_badge")
                    ) {
                        Text(
                            text = "STATUS: PLANNED",
                            color = NovaSandboxAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Estrutura preparada para transferências interbancárias via IBAN ou Número de Conta. Requer provider bancário autorizado.",
                    color = NovaTextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Sub-method selector: IBAN vs ACCOUNT_NUMBER
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NovaNavySurface)
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(10.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    BankTransferSubMethod.entries.forEach { method ->
                        val isSelected = bankSubMethod == method
                        val tag = if (method == BankTransferSubMethod.IBAN) "bank_submethod_iban_tab" else "bank_submethod_account_tab"
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(7.dp))
                                .background(if (isSelected) NovaNavyCard else Color.Transparent)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) NovaGold else Color.Transparent,
                                    shape = RoundedCornerShape(7.dp)
                                )
                                .clickable {
                                    bankSubMethod = method
                                    bankValidationResult = null
                                    ibanErrorMessage = null
                                }
                                .padding(vertical = 8.dp)
                                .testTag(tag),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = method.label,
                                color = if (isSelected) NovaGold else NovaTextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bank Selection Chips
                Text(
                    text = "Selecionar Banco Destino",
                    color = NovaTextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AngolaBanksCatalog.banks.take(4).forEach { bank ->
                        val isSelected = selectedBank.code == bank.code
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NovaGold.copy(alpha = 0.2f) else NovaNavyCard)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) NovaGold else NovaNavyCardBorder,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    selectedBank = bank
                                    bankValidationResult = null
                                    ibanErrorMessage = null
                                    if (bankSubMethod == BankTransferSubMethod.IBAN && !beneficiaryIban.startsWith(bank.ibanPrefix)) {
                                        beneficiaryIban = "${bank.ibanPrefix}.0000.7788.9900.1122.3"
                                    }
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = bank.shortName,
                                    color = if (isSelected) NovaGold else NovaTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "PLANNED",
                                    color = NovaSandboxAmber,
                                    fontSize = 8.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AngolaBanksCatalog.banks.drop(4).forEach { bank ->
                        val isSelected = selectedBank.code == bank.code
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NovaGold.copy(alpha = 0.2f) else NovaNavyCard)
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) NovaGold else NovaNavyCardBorder,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    selectedBank = bank
                                    bankValidationResult = null
                                    ibanErrorMessage = null
                                    if (bankSubMethod == BankTransferSubMethod.IBAN && !beneficiaryIban.startsWith(bank.ibanPrefix)) {
                                        beneficiaryIban = "${bank.ibanPrefix}.0000.7788.9900.1122.3"
                                    }
                                }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = bank.shortName,
                                    color = if (isSelected) NovaGold else NovaTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "PLANNED",
                                    color = NovaSandboxAmber,
                                    fontSize = 8.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Selected Bank display field
                OutlinedTextField(
                    value = "${selectedBank.fullName} [${selectedBank.transferAvailability.name}]",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Banco", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.AccountBalance, null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_bank_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (bankSubMethod == BankTransferSubMethod.IBAN) {
                    OutlinedTextField(
                        value = beneficiaryIban,
                        onValueChange = {
                            beneficiaryIban = it
                            bankValidationResult = null
                            ibanErrorMessage = null
                        },
                        label = { Text("IBAN (AO06...)", color = NovaTextSecondary) },
                        leadingIcon = { Icon(Icons.Default.AccountBalance, null, tint = NovaGold) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaGold,
                            unfocusedBorderColor = NovaNavyCardBorder,
                            focusedTextColor = NovaTextPrimary,
                            unfocusedTextColor = NovaTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("send_iban_input")
                    )
                } else {
                    OutlinedTextField(
                        value = beneficiaryAccountNumber,
                        onValueChange = {
                            beneficiaryAccountNumber = it
                            bankValidationResult = null
                            ibanErrorMessage = null
                        },
                        label = { Text("Número de Conta", color = NovaTextSecondary) },
                        leadingIcon = { Icon(Icons.Default.AccountBalance, null, tint = NovaGold) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaGold,
                            unfocusedBorderColor = NovaNavyCardBorder,
                            focusedTextColor = NovaTextPrimary,
                            unfocusedTextColor = NovaTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("send_account_number_input")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = beneficiaryName,
                    onValueChange = {
                        beneficiaryName = it
                        bankValidationResult = null
                        ibanErrorMessage = null
                    },
                    label = { Text("Titular da Conta", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Person, null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_beneficiary_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = ibanAmountText,
                    onValueChange = {
                        ibanAmountText = it
                        bankValidationResult = null
                        ibanErrorMessage = null
                    },
                    label = { Text("Valor (AOA)", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Payment, null, tint = NovaGold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_amount_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = ibanDescription,
                    onValueChange = {
                        ibanDescription = it
                        bankValidationResult = null
                    },
                    label = {
                        Text(
                            text = if (bankSubMethod == BankTransferSubMethod.IBAN) "Finalidade / Descrição" else "Descrição",
                            color = NovaTextSecondary
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Receipt, null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_description_input")
                )

                if (ibanErrorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaDangerRed.copy(alpha = 0.15f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaDangerRed.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ErrorOutline, null, tint = NovaDangerRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = ibanErrorMessage!!,
                                color = NovaDangerRed,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Provider availability card (PLANNED / NOT_AVAILABLE)
                if (bankValidationResult != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bank_provider_unavailable_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaNavySurface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaSandboxAmber, RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Shield, null, tint = NovaSandboxAmber, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Integração Bancária (${bankValidationResult!!.subMethod.label})",
                                        color = NovaGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                                Text(
                                    text = "STATUS = ${bankValidationResult!!.availabilityStatus.name}",
                                    color = NovaSandboxAmber,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 11.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = bankValidationResult!!.message,
                                color = NovaTextPrimary,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Nenhuma transferência bancária foi simulada nem debitada do seu saldo. Para transferências imediatas no ambiente atual, utilize NOVA → NOVA.",
                                color = NovaTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                NovaButton(
                    text = "Validar Banco / Provider",
                    leadingIcon = Icons.Default.Shield,
                    onClick = {
                        val amount = ibanAmountText.toDoubleOrNull() ?: 0.0
                        val destination = if (bankSubMethod == BankTransferSubMethod.IBAN) beneficiaryIban else beneficiaryAccountNumber
                        val validation = paymentManager.validateBankTransferRequest(
                            subMethod = bankSubMethod,
                            bankCodeOrName = selectedBank.code,
                            ibanOrAccount = destination,
                            accountHolder = beneficiaryName,
                            amount = amount,
                            description = ibanDescription
                        )
                        if (!validation.canExecute) {
                            if (validation.availabilityStatus == IntegrationAvailabilityStatus.PLANNED &&
                                amount > 0 &&
                                beneficiaryName.trim().length >= 3 &&
                                destination.isNotBlank()
                            ) {
                                ibanErrorMessage = null
                                bankValidationResult = validation
                            } else {
                                bankValidationResult = null
                                ibanErrorMessage = validation.message
                            }
                        }
                    },
                    isLoading = isIbanLoading,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "send_submit_button"
                )
            }
        }
    }

    // =========================================================================
    // MODAL DE CONFIRMAÇÃO (MANDATORY REQUIREMENTS 4 & 5)
    // =========================================================================
    if (showConfirmationModal && validatedRecipient != null) {
        val amount = novaAmountText.toDoubleOrNull() ?: 0.0

        Dialog(
            onDismissRequest = {
                if (!isExecutingTransfer) showConfirmationModal = false
            },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .testTag("confirmation_modal_card"),
                    colors = CardDefaults.cardColors(containerColor = NovaNavyDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaGold)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Confirmar Transferência",
                                color = NovaGold,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = {
                                    if (!isExecutingTransfer) showConfirmationModal = false
                                }
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Fechar", tint = NovaTextSecondary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        SandboxBadge(compact = true)
                        Spacer(modifier = Modifier.height(16.dp))

                        // Details Container
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(NovaNavyCard)
                                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            ConfirmDetailRow(label = "Enviar para", value = validatedRecipient!!.displayName)
                            ConfirmDetailRow(label = "Telefone", value = PhoneUtils.formatDisplayPhone(validatedRecipient!!.phone))
                            ConfirmDetailRow(label = "Valor", value = formatAoa(amount))
                            if (novaDescription.isNotBlank()) {
                                ConfirmDetailRow(label = "Descrição", value = novaDescription)
                            }
                            ConfirmDetailRow(label = "Saldo disponível", value = formatAoa(sandboxBalance))
                            ConfirmDetailRow(label = "Taxa", value = "0,00 AOA (Configuração Sandbox)")
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .height(1.dp)
                                    .background(NovaNavyCardBorder)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "Total", color = NovaTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = formatAoa(amount),
                                    color = NovaGold,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Sandbox note as required: "Mostrar 0 AOA somente porque esta operação interna está atualmente configurada no Sandbox. Não apresentar isso como promessa de taxa zero em produção."
                        Text(
                            text = "Operação executada em ambiente Sandbox. A taxa de 0,00 AOA aplica-se estritamente à simulação deste ambiente de testes.",
                            color = NovaSandboxAmber,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )

                        if (transferError != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = NovaDangerRed.copy(alpha = 0.2f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ErrorOutline, null, tint = NovaDangerRed, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = transferError!!,
                                        color = NovaDangerRed,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Action Button with mandatory biometric prompt
                        NovaButton(
                            text = if (transferError != null) "Tentar novamente com segurança" else "Confirmar transferência",
                            leadingIcon = Icons.Default.Fingerprint,
                            onClick = {
                                if (isExecutingTransfer) return@NovaButton
                                requestBiometricAuthorization()
                            },
                            isLoading = isExecutingTransfer,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "confirm_transfer_button"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        NovaButton(
                            text = "Cancelar",
                            isSecondary = true,
                            onClick = {
                                if (!isExecutingTransfer) showConfirmationModal = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }

    // =========================================================================
    // TELA DE RESULTADO DE SUCESSO (MANDATORY REQUIREMENT 7)
    // =========================================================================
    if (completedOperation != null) {
        val op = completedOperation!!

        Dialog(
            onDismissRequest = { /* Must click Concluir */ },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(NovaNavyDark)
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .testTag("transfer_success_card"),
                    colors = CardDefaults.cardColors(containerColor = NovaNavyCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NovaEmerald)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(NovaEmeraldBg)
                                .border(1.dp, NovaEmerald, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Concluído",
                                tint = NovaEmerald,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Transferência realizada",
                            color = NovaEmeraldLight,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "Operação NOVA → NOVA concluída com sucesso.",
                            color = NovaTextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = formatAoa(op.amount),
                            color = NovaGold,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(NovaNavyDark)
                                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            ConfirmDetailRow(label = "Destinatário", value = op.beneficiary)
                            if (!op.beneficiaryAccount.isNullOrBlank()) {
                                ConfirmDetailRow(label = "Telefone", value = PhoneUtils.formatDisplayPhone(op.beneficiaryAccount))
                            }
                            ConfirmDetailRow(label = "Valor", value = formatAoa(op.amount))
                            ConfirmDetailRow(label = "Data/hora", value = op.completedAt ?: op.createdAt)
                            ConfirmDetailRow(label = "Referência NOVA", value = op.reference ?: op.transactionId)
                            ConfirmDetailRow(label = "Estado", value = "Confirmado (COMPLETED)")
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Button: Ver recibo
                        NovaButton(
                            text = "Ver recibo",
                            leadingIcon = Icons.Default.Receipt,
                            onClick = {
                                if (onNavigateToReceipt != null) {
                                    onNavigateToReceipt(op.id)
                                } else {
                                    onNavigateToAuthorize(op.id)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "receipt_view_button"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Button: Partilhar recibo
                        NovaButton(
                            text = "Partilhar recibo",
                            isSecondary = true,
                            leadingIcon = Icons.Default.Share,
                            onClick = {
                                val shareText = """
                                    *NOVA KZ — Transferência Concluída*
                                    ------------------------------------
                                    Tipo: NOVA → NOVA
                                    Destinatário: ${op.beneficiary}
                                    Telefone: ${PhoneUtils.formatDisplayPhone(op.beneficiaryAccount ?: "")}
                                    Valor: ${formatAoa(op.amount)}
                                    Data/Hora: ${op.completedAt ?: op.createdAt}
                                    Referência: ${op.reference ?: op.transactionId}
                                    Estado: Confirmado (COMPLETED)
                                    Ambiente: ${op.environment}
                                    ------------------------------------
                                    Emitido pela aplicação oficial NOVA KZ
                                """.trimIndent()

                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Partilhar recibo de transferência NOVA KZ"))
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "receipt_share_button"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Button: Concluir
                        NovaButton(
                            text = "Concluir",
                            isSecondary = true,
                            onClick = {
                                completedOperation = null
                                onBack()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "receipt_finish_button"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConfirmDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = NovaTextSecondary, fontSize = 12.sp)
        Text(
            text = value,
            color = NovaTextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End
        )
    }
}
