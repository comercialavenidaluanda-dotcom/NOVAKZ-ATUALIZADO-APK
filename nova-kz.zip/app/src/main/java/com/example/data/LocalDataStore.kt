package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

class LocalDataStore(context: Context) {

    private val fallbackPrefs: SharedPreferences =
        context.getSharedPreferences(PREFS_LEGACY_FILE, Context.MODE_PRIVATE)
    private val prefs: SharedPreferences = createSecurePrefs(context, fallbackPrefs)

    companion object {
        private const val TAG = "LocalDataStore"
        private const val PREFS_ENCRYPTED_FILE = "nova_kz_encrypted_prefs"
        private const val PREFS_LEGACY_FILE = "nova_kz_secure_prefs"

        private const val KEY_AUTH_TOKEN = "auth_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_TOKEN_EXPIRES_AT = "token_expires_at"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_PHONE = "user_phone"
        private const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_APP_PIN_HASH = "app_pin_hash"
        private const val KEY_BIOMETRICS_ENABLED = "biometrics_enabled"
        private const val KEY_INACTIVITY_TIMEOUT_MINS = "inactivity_timeout_mins"
        private const val KEY_LAST_INTERACTION_MS = "last_interaction_ms"
        private const val KEY_IS_LOCKED = "is_locked"
        private const val KEY_IS_BALANCE_HIDDEN = "is_balance_hidden"
        private const val KEY_LEGACY_SANDBOX_BALANCE = "sandbox_balance"
        private const val KEY_CACHED_SANDBOX_BALANCE = "cached_backend_sandbox_balance_v2"
        const val DEFAULT_USER_ID = "usr_novakz_sandbox_01"
        private const val KEY_ACCEPTED_TERMS_VERSION = "accepted_terms_version"
        private const val KEY_ACCEPTED_PRIVACY_VERSION = "accepted_privacy_version"
        private const val KEY_ACCEPTED_TERMS = "accepted_terms"
        private const val KEY_ACCEPTED_PRIVACY = "accepted_privacy"
        private const val KEY_LEGAL_ACCEPTED_AT = "legal_accepted_at"
        private const val KEY_STORAGE_MIGRATED = "storage_migrated_v2"

        private fun createSecurePrefs(context: Context, fallbackPrefs: SharedPreferences): SharedPreferences {
            return try {
                val masterKey = MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()

                val securePrefs = EncryptedSharedPreferences.create(
                    context,
                    PREFS_ENCRYPTED_FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )

                // Transparent migration from legacy SharedPreferences (OLD -> NEW)
                migrateLegacyToEncrypted(fallbackPrefs, securePrefs)
                // Remove any legacy hardcoded 1000.0 key so it is never used as source of truth
                if (securePrefs.contains(KEY_LEGACY_SANDBOX_BALANCE)) {
                    securePrefs.edit().remove(KEY_LEGACY_SANDBOX_BALANCE).apply()
                }
                if (fallbackPrefs.contains(KEY_LEGACY_SANDBOX_BALANCE)) {
                    fallbackPrefs.edit().remove(KEY_LEGACY_SANDBOX_BALANCE).apply()
                }
                securePrefs
            } catch (e: Exception) {
                Log.w(TAG, "EncryptedSharedPreferences unavailable (e.g. testing/legacy environment). Falling back to private SharedPreferences.", e)
                if (fallbackPrefs.contains(KEY_LEGACY_SANDBOX_BALANCE)) {
                    fallbackPrefs.edit().remove(KEY_LEGACY_SANDBOX_BALANCE).apply()
                }
                fallbackPrefs
            }
        }

        private fun migrateLegacyToEncrypted(legacyPrefs: SharedPreferences, securePrefs: SharedPreferences) {
            try {
                if (securePrefs.getBoolean(KEY_STORAGE_MIGRATED, false)) return
                val allLegacy = legacyPrefs.all
                if (allLegacy.isNotEmpty()) {
                    Log.i(TAG, "Migrating ${allLegacy.size} entries from legacy storage to EncryptedSharedPreferences...")
                    val editor = securePrefs.edit()
                    for ((key, value) in allLegacy) {
                        if (key == KEY_LEGACY_SANDBOX_BALANCE) continue
                        when (value) {
                            is String -> editor.putString(key, value)
                            is Boolean -> editor.putBoolean(key, value)
                            is Int -> editor.putInt(key, value)
                            is Long -> editor.putLong(key, value)
                            is Float -> editor.putFloat(key, value)
                        }
                    }
                    editor.putBoolean(KEY_STORAGE_MIGRATED, true)
                    editor.apply()
                    Log.i(TAG, "Storage migration completed successfully.")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to migrate legacy preferences to encrypted store", e)
            }
        }
    }

    fun getAcceptedTermsVersion(user: String = userId): String? {
        val userSpecific = prefs.getString("${KEY_ACCEPTED_TERMS_VERSION}_$user", null)
        if (userSpecific != null) return userSpecific
        return if (user == "usr_novakz_sandbox_01" || user == DEFAULT_USER_ID) {
            prefs.getString(KEY_ACCEPTED_TERMS_VERSION, null)
        } else {
            null
        }
    }

    fun getAcceptedPrivacyVersion(user: String = userId): String? {
        val userSpecific = prefs.getString("${KEY_ACCEPTED_PRIVACY_VERSION}_$user", null)
        if (userSpecific != null) return userSpecific
        return if (user == "usr_novakz_sandbox_01" || user == DEFAULT_USER_ID) {
            prefs.getString(KEY_ACCEPTED_PRIVACY_VERSION, null)
        } else {
            null
        }
    }

    fun hasAcceptedTerms(user: String = userId): Boolean {
        val userKey = "${KEY_ACCEPTED_TERMS}_$user"
        if (prefs.contains(userKey)) return prefs.getBoolean(userKey, false)
        return if (user == "usr_novakz_sandbox_01" || user == DEFAULT_USER_ID) {
            prefs.getBoolean(KEY_ACCEPTED_TERMS, false)
        } else {
            false
        }
    }

    fun hasAcceptedPrivacy(user: String = userId): Boolean {
        val userKey = "${KEY_ACCEPTED_PRIVACY}_$user"
        if (prefs.contains(userKey)) return prefs.getBoolean(userKey, false)
        return if (user == "usr_novakz_sandbox_01" || user == DEFAULT_USER_ID) {
            prefs.getBoolean(KEY_ACCEPTED_PRIVACY, false)
        } else {
            false
        }
    }

    fun getLegalAcceptedAt(user: String = userId): Long {
        val userKey = "${KEY_LEGAL_ACCEPTED_AT}_$user"
        if (prefs.contains(userKey)) return prefs.getLong(userKey, 0L)
        return if (user == "usr_novakz_sandbox_01" || user == DEFAULT_USER_ID) {
            prefs.getLong(KEY_LEGAL_ACCEPTED_AT, 0L)
        } else {
            0L
        }
    }

    fun setLegalAcceptance(
        user: String = userId,
        termsVersion: String,
        privacyVersion: String,
        termsAccepted: Boolean,
        privacyAccepted: Boolean,
        acceptedAt: Long = System.currentTimeMillis()
    ) {
        val editor = prefs.edit()
            // Per user
            .putString("${KEY_ACCEPTED_TERMS_VERSION}_$user", termsVersion)
            .putString("${KEY_ACCEPTED_PRIVACY_VERSION}_$user", privacyVersion)
            .putBoolean("${KEY_ACCEPTED_TERMS}_$user", termsAccepted)
            .putBoolean("${KEY_ACCEPTED_PRIVACY}_$user", privacyAccepted)
            .putLong("${KEY_LEGAL_ACCEPTED_AT}_$user", acceptedAt)

        if (user == DEFAULT_USER_ID) {
            editor.putString(KEY_ACCEPTED_TERMS_VERSION, termsVersion)
                .putString(KEY_ACCEPTED_PRIVACY_VERSION, privacyVersion)
                .putBoolean(KEY_ACCEPTED_TERMS, termsAccepted)
                .putBoolean(KEY_ACCEPTED_PRIVACY, privacyAccepted)
                .putLong(KEY_LEGAL_ACCEPTED_AT, acceptedAt)
        }
        editor.apply()
    }

    fun clearLegalAcceptance(user: String = userId) {
        prefs.edit()
            .remove("${KEY_ACCEPTED_TERMS_VERSION}_$user")
            .remove("${KEY_ACCEPTED_PRIVACY_VERSION}_$user")
            .remove("${KEY_ACCEPTED_TERMS}_$user")
            .remove("${KEY_ACCEPTED_PRIVACY}_$user")
            .remove("${KEY_LEGAL_ACCEPTED_AT}_$user")
            .remove(KEY_ACCEPTED_TERMS_VERSION)
            .remove(KEY_ACCEPTED_PRIVACY_VERSION)
            .remove(KEY_ACCEPTED_TERMS)
            .remove(KEY_ACCEPTED_PRIVACY)
            .remove(KEY_LEGAL_ACCEPTED_AT)
            .apply()
    }

    var acceptedTermsVersion: String?
        get() = getAcceptedTermsVersion(userId)
        set(value) {
            val editor = prefs.edit()
            if (value == null) {
                editor.remove(KEY_ACCEPTED_TERMS_VERSION)
                editor.remove("${KEY_ACCEPTED_TERMS_VERSION}_$userId")
            } else {
                editor.putString(KEY_ACCEPTED_TERMS_VERSION, value)
                editor.putString("${KEY_ACCEPTED_TERMS_VERSION}_$userId", value)
            }
            editor.apply()
        }

    var acceptedPrivacyVersion: String?
        get() = getAcceptedPrivacyVersion(userId)
        set(value) {
            val editor = prefs.edit()
            if (value == null) {
                editor.remove(KEY_ACCEPTED_PRIVACY_VERSION)
                editor.remove("${KEY_ACCEPTED_PRIVACY_VERSION}_$userId")
            } else {
                editor.putString(KEY_ACCEPTED_PRIVACY_VERSION, value)
                editor.putString("${KEY_ACCEPTED_PRIVACY_VERSION}_$userId", value)
            }
            editor.apply()
        }

    var acceptedTerms: Boolean
        get() = hasAcceptedTerms(userId)
        set(value) {
            prefs.edit()
                .putBoolean(KEY_ACCEPTED_TERMS, value)
                .putBoolean("${KEY_ACCEPTED_TERMS}_$userId", value)
                .apply()
        }

    var acceptedPrivacy: Boolean
        get() = hasAcceptedPrivacy(userId)
        set(value) {
            prefs.edit()
                .putBoolean(KEY_ACCEPTED_PRIVACY, value)
                .putBoolean("${KEY_ACCEPTED_PRIVACY}_$userId", value)
                .apply()
        }

    var legalAcceptedAt: Long
        get() = getLegalAcceptedAt(userId)
        set(value) {
            prefs.edit()
                .putLong(KEY_LEGAL_ACCEPTED_AT, value)
                .putLong("${KEY_LEGAL_ACCEPTED_AT}_$userId", value)
                .apply()
        }

    var isBalanceHidden: Boolean
        get() = prefs.getBoolean(KEY_IS_BALANCE_HIDDEN, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_BALANCE_HIDDEN, value).apply()

    var authToken: String?
        get() = prefs.getString(KEY_AUTH_TOKEN, null) ?: fallbackPrefs.getString(KEY_AUTH_TOKEN, null)
        set(value) {
            prefs.edit().putString(KEY_AUTH_TOKEN, value).apply()
            fallbackPrefs.edit().putString(KEY_AUTH_TOKEN, value).apply()
        }

    var refreshToken: String?
        get() = prefs.getString(KEY_REFRESH_TOKEN, null) ?: fallbackPrefs.getString(KEY_REFRESH_TOKEN, null)
        set(value) {
            prefs.edit().putString(KEY_REFRESH_TOKEN, value).apply()
            fallbackPrefs.edit().putString(KEY_REFRESH_TOKEN, value).apply()
        }

    var tokenExpiresAt: Long
        get() {
            val v = prefs.getLong(KEY_TOKEN_EXPIRES_AT, 0L)
            return if (v > 0L) v else fallbackPrefs.getLong(KEY_TOKEN_EXPIRES_AT, 0L)
        }
        set(value) {
            prefs.edit().putLong(KEY_TOKEN_EXPIRES_AT, value).apply()
            fallbackPrefs.edit().putLong(KEY_TOKEN_EXPIRES_AT, value).apply()
        }

    fun isTokenExpired(bufferSeconds: Long = 60L): Boolean {
        val expiresAt = tokenExpiresAt
        if (expiresAt <= 0L) return false // No expiration recorded or sandbox
        return System.currentTimeMillis() + (bufferSeconds * 1000L) >= expiresAt
    }

    fun hasActiveSession(): Boolean {
        val token = authToken
        val refresh = refreshToken
        return !token.isNullOrBlank() || !refresh.isNullOrBlank()
    }

    fun saveSession(
        accessToken: String,
        newRefreshToken: String? = null,
        expiresInSeconds: Long? = 3600L
    ) {
        val editor = prefs.edit()
        val fallbackEditor = fallbackPrefs.edit()
        editor.putString(KEY_AUTH_TOKEN, accessToken)
        fallbackEditor.putString(KEY_AUTH_TOKEN, accessToken)
        if (!newRefreshToken.isNullOrBlank()) {
            editor.putString(KEY_REFRESH_TOKEN, newRefreshToken)
            fallbackEditor.putString(KEY_REFRESH_TOKEN, newRefreshToken)
        }
        if (expiresInSeconds != null && expiresInSeconds > 0L) {
            val expiresAt = System.currentTimeMillis() + (expiresInSeconds * 1000L)
            editor.putLong(KEY_TOKEN_EXPIRES_AT, expiresAt)
            fallbackEditor.putLong(KEY_TOKEN_EXPIRES_AT, expiresAt)
        }
        editor.apply()
        fallbackEditor.apply()
    }

    var userId: String
        get() = prefs.getString(KEY_USER_ID, null)
            ?: fallbackPrefs.getString(KEY_USER_ID, "usr_novakz_sandbox_01")
            ?: "usr_novakz_sandbox_01"
        set(value) {
            prefs.edit().putString(KEY_USER_ID, value).apply()
            fallbackPrefs.edit().putString(KEY_USER_ID, value).apply()
        }

    var userEmail: String
        get() = prefs.getString(KEY_USER_EMAIL, null)
            ?: fallbackPrefs.getString(KEY_USER_EMAIL, "comercialavenidaluanda@gmail.com")
            ?: "comercialavenidaluanda@gmail.com"
        set(value) {
            prefs.edit().putString(KEY_USER_EMAIL, value).apply()
            fallbackPrefs.edit().putString(KEY_USER_EMAIL, value).apply()
        }

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, null)
            ?: fallbackPrefs.getString(KEY_USER_NAME, "Utilizador NOVA KZ")
            ?: "Utilizador NOVA KZ"
        set(value) {
            prefs.edit().putString(KEY_USER_NAME, value).apply()
            fallbackPrefs.edit().putString(KEY_USER_NAME, value).apply()
        }

    var userPhone: String
        get() = prefs.getString(KEY_USER_PHONE, null)
            ?: fallbackPrefs.getString(KEY_USER_PHONE, "+244 923 000 000")
            ?: "+244 923 000 000"
        set(value) {
            prefs.edit().putString(KEY_USER_PHONE, value).apply()
            fallbackPrefs.edit().putString(KEY_USER_PHONE, value).apply()
        }

    var fcmToken: String?
        get() = prefs.getString(KEY_FCM_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_FCM_TOKEN, value).apply()

    var isBiometricsEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRICS_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRICS_ENABLED, value).apply()

    var isBiometricEnabled: Boolean
        get() = isBiometricsEnabled
        set(value) { isBiometricsEnabled = value }

    var inactivityTimeoutMinutes: Int
        get() = prefs.getInt(KEY_INACTIVITY_TIMEOUT_MINS, 3)
        set(value) = prefs.edit().putInt(KEY_INACTIVITY_TIMEOUT_MINS, value).apply()

    var lastInteractionTimestamp: Long
        get() = prefs.getLong(KEY_LAST_INTERACTION_MS, System.currentTimeMillis())
        set(value) = prefs.edit().putLong(KEY_LAST_INTERACTION_MS, value).apply()

    var isAppLocked: Boolean
        get() = prefs.getBoolean(KEY_IS_LOCKED, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_LOCKED, value).apply()

    /**
     * Returns the last backend-verified visual cache for the user's Sandbox balance,
     * or null if no backend balance has been cached yet.
     * NEVER returns a hardcoded 1000.0 default.
     */
    fun getCachedSandboxBalance(user: String = userId): Double? {
        val userKey = "${KEY_CACHED_SANDBOX_BALANCE}_$user"
        if (prefs.contains(userKey)) {
            return java.lang.Double.longBitsToDouble(prefs.getLong(userKey, 0L))
        }
        if (fallbackPrefs.contains(userKey)) {
            return java.lang.Double.longBitsToDouble(fallbackPrefs.getLong(userKey, 0L))
        }
        if (prefs.contains(KEY_CACHED_SANDBOX_BALANCE)) {
            return java.lang.Double.longBitsToDouble(prefs.getLong(KEY_CACHED_SANDBOX_BALANCE, 0L))
        }
        if (fallbackPrefs.contains(KEY_CACHED_SANDBOX_BALANCE)) {
            return java.lang.Double.longBitsToDouble(fallbackPrefs.getLong(KEY_CACHED_SANDBOX_BALANCE, 0L))
        }
        return null
    }

    fun setCachedSandboxBalance(balance: Double, user: String = userId) {
        val bits = java.lang.Double.doubleToLongBits(balance)
        val userKey = "${KEY_CACHED_SANDBOX_BALANCE}_$user"
        prefs.edit()
            .putLong(userKey, bits)
            .putLong(KEY_CACHED_SANDBOX_BALANCE, bits)
            .apply()
        fallbackPrefs.edit()
            .putLong(userKey, bits)
            .putLong(KEY_CACHED_SANDBOX_BALANCE, bits)
            .apply()
    }

    fun clearSandboxBalanceCache(user: String = userId) {
        val userKey = "${KEY_CACHED_SANDBOX_BALANCE}_$user"
        prefs.edit()
            .remove(userKey)
            .remove(KEY_CACHED_SANDBOX_BALANCE)
            .remove(KEY_LEGACY_SANDBOX_BALANCE)
            .apply()
        fallbackPrefs.edit()
            .remove(userKey)
            .remove(KEY_CACHED_SANDBOX_BALANCE)
            .remove(KEY_LEGACY_SANDBOX_BALANCE)
            .apply()
    }

    var sandboxBalance: Double
        get() = getCachedSandboxBalance(userId) ?: 0.0
        set(value) = setCachedSandboxBalance(value, userId)

    fun hasAppPin(): Boolean {
        return prefs.getString(KEY_APP_PIN_HASH, null) != null
    }

    fun setAppPin(pin: String) {
        val hash = hashPin(pin)
        prefs.edit().putString(KEY_APP_PIN_HASH, hash).apply()
    }

    fun verifyAppPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_APP_PIN_HASH, null) ?: return pin == "1234"
        return storedHash == hashPin(pin)
    }

    private fun hashPin(pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest("nova_kz_salt_$pin".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun clearSession() {
        val userKey = "${KEY_CACHED_SANDBOX_BALANCE}_$userId"
        prefs.edit()
            .remove(KEY_AUTH_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_TOKEN_EXPIRES_AT)
            .remove(KEY_IS_LOCKED)
            .remove(userKey)
            .remove(KEY_CACHED_SANDBOX_BALANCE)
            .remove(KEY_LEGACY_SANDBOX_BALANCE)
            .apply()
        fallbackPrefs.edit()
            .remove(KEY_AUTH_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .remove(KEY_TOKEN_EXPIRES_AT)
            .remove(KEY_IS_LOCKED)
            .remove(userKey)
            .remove(KEY_CACHED_SANDBOX_BALANCE)
            .remove(KEY_LEGACY_SANDBOX_BALANCE)
            .apply()
    }
}
