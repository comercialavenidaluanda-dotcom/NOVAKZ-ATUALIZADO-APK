package com.example.core.transaction

import com.example.domain.models.PaymentStatus

/**
 * Mapper único e consistente para apresentação visual dos estados de transação no NOVA KZ.
 *
 * Mapeamento oficial:
 * - CREATED    -> Criado
 * - PENDING    -> Em processamento
 * - PROCESSING -> A processar
 * - SUCCEEDED  -> Concluído
 * - FAILED     -> Falhou
 * - EXPIRED    -> Expirado
 * - CANCELLED  -> Cancelado
 * - REFUNDED   -> Reembolsado
 */
object TransactionStatusMapper {

    fun toDisplayLabel(status: PaymentStatus): String {
        return when (status) {
            PaymentStatus.CREATED,
            PaymentStatus.DRAFT,
            PaymentStatus.VALIDATED -> "Criado"

            PaymentStatus.PENDING,
            PaymentStatus.PENDING_AUTHORIZATION -> "Em processamento"

            PaymentStatus.PROCESSING,
            PaymentStatus.AUTHORIZED -> "A processar"

            PaymentStatus.SUCCEEDED,
            PaymentStatus.CONFIRMED -> "Concluído"

            PaymentStatus.FAILED,
            PaymentStatus.REJECTED -> "Falhou"

            PaymentStatus.EXPIRED -> "Expirado"

            PaymentStatus.CANCELLED -> "Cancelado"

            PaymentStatus.REFUNDED -> "Reembolsado"
        }
    }

    fun toDisplayLabel(rawStatus: String?): String {
        val status = PaymentStatus.fromBackendString(rawStatus)
        return toDisplayLabel(status)
    }

    fun fromBackendStatus(rawStatus: String?): PaymentStatus {
        return PaymentStatus.fromBackendString(rawStatus)
    }

    fun isFinalSuccess(status: PaymentStatus): Boolean {
        return status == PaymentStatus.SUCCEEDED || status == PaymentStatus.CONFIRMED
    }

    fun isPendingOrProcessing(status: PaymentStatus): Boolean {
        return status in listOf(
            PaymentStatus.CREATED,
            PaymentStatus.PENDING,
            PaymentStatus.PENDING_AUTHORIZATION,
            PaymentStatus.AUTHORIZED,
            PaymentStatus.PROCESSING
        )
    }

    fun isFailureOrExpired(status: PaymentStatus): Boolean {
        return status in listOf(
            PaymentStatus.FAILED,
            PaymentStatus.REJECTED,
            PaymentStatus.EXPIRED,
            PaymentStatus.CANCELLED
        )
    }
}
