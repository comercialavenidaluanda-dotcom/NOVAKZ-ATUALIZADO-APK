package com.example.core.environment

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/**
 * Ambientes operacionais oficiais do ecossistema NOVA KZ.
 */
enum class NovaEnvironment(
    val code: String,
    val displayName: String,
    val badgeText: String,
    val disclaimerText: String
) {
    SANDBOX(
        code = "SANDBOX",
        displayName = "Sandbox",
        badgeText = "SANDBOX",
        disclaimerText = "Ambiente de Testes Sandbox • Operações validadas via backend Supabase."
    ),
    HOMOLOGATION(
        code = "HOMOLOGATION",
        displayName = "Homologação",
        badgeText = "HOMOLOGAÇÃO",
        disclaimerText = "Ambiente de Homologação • Métodos configurados para certificação técnica com parceiros."
    ),
    PRODUCTION(
        code = "PRODUCTION",
        displayName = "Produção",
        badgeText = "PRODUÇÃO",
        disclaimerText = "Ambiente de Produção NOVA KZ • Operações financeiras processadas em tempo real."
    );

    companion object {
        fun fromString(raw: String?): NovaEnvironment {
            return when (raw?.trim()?.uppercase()) {
                "PRODUCTION", "PROD", "LIVE" -> PRODUCTION
                "HOMOLOGATION", "HOMOLOGACAO", "HOMOLOGAÇÃO", "STAGING", "UAT" -> HOMOLOGATION
                else -> SANDBOX
            }
        }
    }
}

typealias PaymentEnvironment = NovaEnvironment

/**
 * Estado operacional de cada método de pagamento no NOVA KZ.
 */
enum class MethodAvailabilityState(val statusText: String, val badgeLabel: String) {
    AVAILABLE_FOR_HOMOLOGATION(
        statusText = "Disponível para configuração / Homologação",
        badgeLabel = "HOMOLOGAÇÃO / CONFIGURAÇÃO"
    ),
    ACTIVE(
        statusText = "Ativo",
        badgeLabel = "ATIVO"
    ),
    COMING_SOON(
        statusText = "Brevemente",
        badgeLabel = "BREVEMENTE"
    ),
    DISABLED(
        statusText = "Indisponível temporariamente",
        badgeLabel = "INDISPONÍVEL"
    )
}

/**
 * Configuração dinâmica recebida do backend (ou padrão seguro de homologação) para cada método.
 */
data class DynamicMethodConfig(
    val methodCode: String,
    val displayName: String,
    val description: String,
    val isActive: Boolean,
    val isAvailable: Boolean,
    val availabilityState: MethodAvailabilityState,
    val environment: NovaEnvironment,
    val minAmountAoa: Double = 10.0,
    val maxAmountAoa: Double = 5_000_000.0,
    val statusMessage: String = availabilityState.statusText
)

/**
 * Configuração centralizada de ambiente e disponibilidade dinâmica de métodos do NOVA KZ.
 * Nenhuma chave privada ou segredo de PSP é armazenado no cliente Android.
 */
object NovaEnvironmentConfig {
    private val _environmentFlow = MutableStateFlow(NovaEnvironment.SANDBOX)
    val environmentFlow: StateFlow<NovaEnvironment> = _environmentFlow.asStateFlow()

    val environment: NovaEnvironment
        get() = _environmentFlow.value

    val isSandbox: Boolean
        get() = _environmentFlow.value == NovaEnvironment.SANDBOX

    val isHomologation: Boolean
        get() = _environmentFlow.value == NovaEnvironment.HOMOLOGATION

    val isProduction: Boolean
        get() = _environmentFlow.value == NovaEnvironment.PRODUCTION

    private val defaultMethodConfigs = listOf(
        DynamicMethodConfig(
            methodCode = "MULTICAIXA_EXPRESS",
            displayName = "Multicaixa Express",
            description = "Pagamento através de Express.",
            isActive = true,
            isAvailable = true,
            availabilityState = MethodAvailabilityState.AVAILABLE_FOR_HOMOLOGATION,
            environment = NovaEnvironment.SANDBOX,
            minAmountAoa = 10.0,
            maxAmountAoa = 2_500_000.0,
            statusMessage = "Disponível para configuração / Homologação"
        ),
        DynamicMethodConfig(
            methodCode = "REFERENCE_PAYMENT",
            displayName = "Referência Multicaixa",
            description = "Pagamento através de referência.",
            isActive = true,
            isAvailable = true,
            availabilityState = MethodAvailabilityState.AVAILABLE_FOR_HOMOLOGATION,
            environment = NovaEnvironment.SANDBOX,
            minAmountAoa = 10.0,
            maxAmountAoa = 10_000_000.0,
            statusMessage = "Disponível para configuração / Homologação"
        ),
        DynamicMethodConfig(
            methodCode = "UNITEL_MONEY",
            displayName = "Unitel Money",
            description = "Carteira digital móvel.",
            isActive = false,
            isAvailable = false,
            availabilityState = MethodAvailabilityState.COMING_SOON,
            environment = NovaEnvironment.SANDBOX,
            statusMessage = "Brevemente"
        ),
        DynamicMethodConfig(
            methodCode = "KWIK",
            displayName = "KWiK",
            description = "Pagamentos instantâneos interbancários.",
            isActive = false,
            isAvailable = false,
            availabilityState = MethodAvailabilityState.COMING_SOON,
            environment = NovaEnvironment.SANDBOX,
            statusMessage = "Brevemente"
        ),
        DynamicMethodConfig(
            methodCode = "DIRECT_DEBIT",
            displayName = "Débito Directo",
            description = "Autorização de débito em conta bancária.",
            isActive = false,
            isAvailable = false,
            availabilityState = MethodAvailabilityState.COMING_SOON,
            environment = NovaEnvironment.SANDBOX,
            statusMessage = "Brevemente"
        ),
        DynamicMethodConfig(
            methodCode = "INTERNATIONAL_CARDS",
            displayName = "Cartões Internacionais",
            description = "Visa / Mastercard com 3D Secure.",
            isActive = false,
            isAvailable = false,
            availabilityState = MethodAvailabilityState.COMING_SOON,
            environment = NovaEnvironment.SANDBOX,
            statusMessage = "Brevemente"
        )
    )

    private val _methodConfigs = MutableStateFlow(defaultMethodConfigs)
    val methodConfigs: StateFlow<List<DynamicMethodConfig>> = _methodConfigs.asStateFlow()

    fun setEnvironment(env: NovaEnvironment) {
        _environmentFlow.value = env
    }

    fun getMethodConfig(methodCode: String): DynamicMethodConfig {
        return _methodConfigs.value.find { it.methodCode.equals(methodCode, ignoreCase = true) }
            ?: defaultMethodConfigs.first()
    }

    fun getAvailableMethods(): List<DynamicMethodConfig> {
        return _methodConfigs.value.filter { it.isAvailable && it.availabilityState != MethodAvailabilityState.COMING_SOON }
    }

    fun getComingSoonMethods(): List<DynamicMethodConfig> {
        return _methodConfigs.value.filter { it.availabilityState == MethodAvailabilityState.COMING_SOON }
    }

    /**
     * Atualiza a configuração dinâmica a partir de payload JSON enviado pelo backend Supabase.
     */
    fun applyBackendDynamicConfig(json: JSONObject) {
        if (json.has("environment")) {
            _environmentFlow.value = NovaEnvironment.fromString(json.optString("environment"))
        }
        val methodsArray = json.optJSONArray("methods") ?: return
        val updated = _methodConfigs.value.toMutableList()
        for (i in 0 until methodsArray.length()) {
            val item = methodsArray.optJSONObject(i) ?: continue
            val code = item.optString("method_code", item.optString("code", ""))
            if (code.isBlank()) continue
            val idx = updated.indexOfFirst { it.methodCode.equals(code, ignoreCase = true) }
            val active = item.optBoolean("active", false)
            val available = item.optBoolean("available", active)
            val env = NovaEnvironment.fromString(item.optString("environment", _environmentFlow.value.code))
            val minLimit = item.optDouble("min_amount", 10.0)
            val maxLimit = item.optDouble("max_amount", 5_000_000.0)
            val msg = item.optString("message", if (available) "Disponível para configuração / Homologação" else "Brevemente")
            val state = when {
                !available -> MethodAvailabilityState.COMING_SOON
                env == NovaEnvironment.PRODUCTION && active -> MethodAvailabilityState.ACTIVE
                else -> MethodAvailabilityState.AVAILABLE_FOR_HOMOLOGATION
            }
            if (idx >= 0) {
                updated[idx] = updated[idx].copy(
                    isActive = active,
                    isAvailable = available,
                    availabilityState = state,
                    environment = env,
                    minAmountAoa = minLimit,
                    maxAmountAoa = maxLimit,
                    statusMessage = msg
                )
            }
        }
        _methodConfigs.value = updated
    }

    fun resetToDefaults() {
        _environmentFlow.value = NovaEnvironment.SANDBOX
        _methodConfigs.value = defaultMethodConfigs
    }
}
