package com.example.core.security

import android.util.Log

/**
 * Logger seguro do NOVA KZ com sanitização automática de dados sensíveis.
 * Garante que PIN, password, access_token, refresh_token, API keys, secrets,
 * IBANs completos e payloads financeiros confidenciais nunca sejam expostos no Logcat.
 */
object NovaLogger {

    private val keyValueSecretRegex = Regex(
        """(?i)("(?:pin|password|pass|access_token|refresh_token|apikey|api_key|secret|service_role|authorization|bearer|cvv|card_number|iban|account_number)"\s*:\s*")([^"]*)(")"""
    )

    private val queryOrParamSecretRegex = Regex(
        """(?i)\b(pin|password|access_token|refresh_token|api_key|apikey|secret|service_role|token|iban)=([^\s&",;]+)""",
    )

    private val bearerJwtRegex = Regex(
        """(?i)(Bearer\s+)?eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"""
    )

    private val angolaIbanRegex = Regex(
        """AO06[\s.]?\d{4}[\s.]?\d{4}[\s.]?\d{4}[\s.]?\d{4}[\s.]?\d{4}[\s.]?\d"""
    )

    private val longDigitSequenceRegex = Regex(
        """\b\d{9,21}\b"""
    )

    /**
     * Remove ou mascara qualquer dado sensível antes de registar ou exibir mensagens de diagnóstico.
     */
    fun sanitize(raw: String?): String {
        if (raw.isNullOrEmpty()) return ""
        var result = raw
        result = keyValueSecretRegex.replace(result) { match ->
            "${match.groupValues[1]}[REDACTED]${match.groupValues[3]}"
        }
        result = queryOrParamSecretRegex.replace(result) { match ->
            "${match.groupValues[1]}=[REDACTED]"
        }
        result = bearerJwtRegex.replace(result, "[REDACTED_JWT]")
        result = angolaIbanRegex.replace(result) { match ->
            val clean = match.value.replace(" ", "").replace(".", "")
            if (clean.length >= 8) "${clean.take(4)}...${clean.takeLast(3)}" else "[REDACTED_IBAN]"
        }
        result = longDigitSequenceRegex.replace(result) { match ->
            val digits = match.value
            if (digits.length >= 9) "***${digits.takeLast(3)}" else digits
        }
        return result
    }

    fun d(tag: String, message: String) {
        try {
            Log.d(tag, sanitize(message))
        } catch (_: Exception) {
            // Ignore in pure unit test environments where android.util.Log is not mocked
        }
    }

    fun i(tag: String, message: String) {
        try {
            Log.i(tag, sanitize(message))
        } catch (_: Exception) {
        }
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        try {
            if (throwable != null) {
                Log.w(tag, sanitize(message), throwable)
            } else {
                Log.w(tag, sanitize(message))
            }
        } catch (_: Exception) {
        }
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        try {
            if (throwable != null) {
                Log.e(tag, sanitize(message), throwable)
            } else {
                Log.e(tag, sanitize(message))
            }
        } catch (_: Exception) {
        }
    }
}
