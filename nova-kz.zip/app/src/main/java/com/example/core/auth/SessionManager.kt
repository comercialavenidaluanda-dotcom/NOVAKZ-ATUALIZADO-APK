package com.example.core.auth

import com.example.auth.AuthManager
import com.example.core.security.NovaLogger
import com.example.data.LocalDataStore
import com.example.network.SupabaseRestClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Estado da sessão gerido centralmente pelo SessionManager.
 */
enum class SessionRecoveryState {
    VALID,
    REFRESHING,
    REAUTH_REQUIRED,
    UNAUTHENTICATED
}

/**
 * Métodos disponíveis para recuperação de sessão sem forçar logout destrutivo.
 */
enum class SessionRecoveryMethod {
    PIN,
    PASSWORD,
    BIOMETRIC
}

/**
 * Gestor central de sessão do NOVA KZ:
 *
 * Supabase Auth
 *      ↓
 * SessionManager
 *      ↓
 * Token válido?
 *      ↓
 * SIM → continuar
 * NÃO → refresh
 *      ↓
 * falhou
 *      ↓
 * pedir autenticação novamente (PIN, autenticação normal ou biometria quando disponível)
 */
class SessionManager(
    private val dataStore: LocalDataStore,
    private val restClient: SupabaseRestClient,
    private val authManager: AuthManager
) {
    private val _sessionState = MutableStateFlow(evaluateInitialState())
    val sessionState: StateFlow<SessionRecoveryState> = _sessionState.asStateFlow()

    private fun evaluateInitialState(): SessionRecoveryState {
        return when {
            !dataStore.hasActiveSession() -> SessionRecoveryState.UNAUTHENTICATED
            dataStore.isTokenExpired() -> SessionRecoveryState.REAUTH_REQUIRED
            else -> SessionRecoveryState.VALID
        }
    }

    /**
     * Verifica se o token atual é válido; se tiver expirado, tenta renová-lo silenciosamente via refresh_token.
     * Nunca efetua logout destrutivo automaticamente se o refresh falhar — solicita reautenticação segura.
     */
    suspend fun ensureValidSession(): Boolean {
        if (!dataStore.hasActiveSession() && !authManager.isAuthenticated.value) {
            _sessionState.value = SessionRecoveryState.UNAUTHENTICATED
            return false
        }

        if (!dataStore.isTokenExpired()) {
            _sessionState.value = SessionRecoveryState.VALID
            return true
        }

        _sessionState.value = SessionRecoveryState.REFRESHING
        NovaLogger.i(TAG, "Token expirado; a tentar renovação automática de sessão...")

        val refreshed = authManager.ensureValidSession()
        return if (refreshed && !dataStore.isTokenExpired()) {
            _sessionState.value = SessionRecoveryState.VALID
            true
        } else {
            NovaLogger.w(TAG, "Renovação automática não concluída; a solicitar reautenticação ao utilizador.")
            _sessionState.value = SessionRecoveryState.REAUTH_REQUIRED
            false
        }
    }

    /**
     * Recupera a sessão utilizando o PIN da aplicação (funciona mesmo em dispositivos sem biometria).
     */
    fun recoverSessionWithPin(pin: String): Boolean {
        if (!dataStore.verifyAppPin(pin)) {
            return false
        }
        // Renova janela local se utilizador validou com PIN
        val currentAccess = dataStore.authToken ?: "session_pin_verified_${System.currentTimeMillis()}"
        val currentRefresh = dataStore.refreshToken
        dataStore.saveSession(
            accessToken = currentAccess,
            newRefreshToken = currentRefresh,
            expiresInSeconds = 3600L
        )
        _sessionState.value = SessionRecoveryState.VALID
        return true
    }

    /**
     * Marca a sessão como recuperada após biometria ou login normal bem-sucedido.
     */
    fun markSessionRecovered() {
        val currentAccess = dataStore.authToken ?: return
        dataStore.saveSession(
            accessToken = currentAccess,
            newRefreshToken = dataStore.refreshToken,
            expiresInSeconds = 3600L
        )
        _sessionState.value = SessionRecoveryState.VALID
    }

    fun requireReauthentication() {
        _sessionState.value = SessionRecoveryState.REAUTH_REQUIRED
    }

    fun getAvailableRecoveryMethods(isBiometricHardwareAvailable: Boolean): List<SessionRecoveryMethod> {
        val methods = mutableListOf(SessionRecoveryMethod.PIN, SessionRecoveryMethod.PASSWORD)
        if (isBiometricHardwareAvailable) {
            methods.add(SessionRecoveryMethod.BIOMETRIC)
        }
        return methods
    }

    companion object {
        private const val TAG = "SessionManager"
    }
}
