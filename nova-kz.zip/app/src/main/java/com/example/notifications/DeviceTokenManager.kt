package com.example.notifications

import com.example.core.security.NovaLogger
import com.example.data.LocalDataStore
import com.example.network.SupabaseRestClient
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DeviceTokenManager(
    private val dataStore: LocalDataStore,
    private val restClient: SupabaseRestClient,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "DeviceTokenManager"
    }

    fun syncCurrentTokenWithUser(userId: String) {
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    NovaLogger.w(TAG, "Fetching FCM registration token failed", task.exception)
                    return@addOnCompleteListener
                }

                // Get new FCM registration token
                val token = task.result
                NovaLogger.d(TAG, "Retrieved FCM Registration Token (redacted)")
                dataStore.fcmToken = token

                scope.launch(Dispatchers.IO) {
                    try {
                        restClient.upsertDeviceToken(
                            userId = userId,
                            token = token,
                            platform = "android"
                        )
                        NovaLogger.i(TAG, "FCM token registered with Supabase nova_kz_device_tokens")
                    } catch (e: Exception) {
                        NovaLogger.e(TAG, "Error associating token with backend", e)
                    }
                }
            }
    }

    fun onTokenRefresh(newToken: String) {
        NovaLogger.d(TAG, "FCM Token refreshed (redacted)")
        dataStore.fcmToken = newToken
        val userId = dataStore.userId
        if (dataStore.authToken != null && userId.isNotBlank()) {
            scope.launch(Dispatchers.IO) {
                try {
                    restClient.upsertDeviceToken(userId, newToken, "android")
                } catch (e: Exception) {
                    NovaLogger.e(TAG, "Error updating refreshed token", e)
                }
            }
        }
    }

    suspend fun deactivateCurrentDevice(token: String) {
        try {
            restClient.deactivateDeviceToken(token)
            NovaLogger.i(TAG, "Device token deactivated")
        } catch (e: Exception) {
            NovaLogger.e(TAG, "Error deactivating token", e)
        }
    }
}
