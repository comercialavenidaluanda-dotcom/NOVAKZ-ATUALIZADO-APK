package com.example.notifications

import com.example.NovaKzApplication
import com.example.core.security.NovaLogger
import com.example.domain.models.NotificationCategory
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class NovaKzFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        NovaLogger.d(TAG, "Refreshed FCM token received (redacted)")
        try {
            val app = application as? NovaKzApplication
            app?.dataStore?.fcmToken = token
        } catch (e: Exception) {
            NovaLogger.e(TAG, "Error handling new token", e)
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        NovaLogger.d(TAG, "FCM Message received")

        val data = remoteMessage.data
        val notification = remoteMessage.notification

        val title = notification?.title ?: data["title"] ?: "NOVA KZ"
        val body = notification?.body ?: data["body"] ?: "Tem uma nova atualização na sua conta."
        val categoryStr = data["category"] ?: "PAYMENT_DONE"
        val amountStr = data["amount"]
        val reference = data["reference"]
        val operationId = data["operation_id"]

        val amount = amountStr?.toDoubleOrNull()
        val category = try {
            NotificationCategory.valueOf(categoryStr)
        } catch (e: Exception) {
            NotificationCategory.PAYMENT_DONE
        }

        NotificationHelper.showSystemNotification(
            context = applicationContext,
            title = title,
            body = body,
            category = category,
            amount = amount,
            reference = reference,
            operationId = operationId
        )
    }

    companion object {
        private const val TAG = "NovaKzFCM"
    }
}
