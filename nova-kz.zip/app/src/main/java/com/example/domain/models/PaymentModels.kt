package com.example.domain.models

import java.util.UUID

enum class PaymentType(val label: String, val backendOperationType: String) {
    TRANSFER("Transferência", "TRANSFER"),
    NOVA_TO_NOVA("NOVA → NOVA", "TRANSFER"),
    BANK_TRANSFER("Transferência Bancária", "TRANSFER"),
    MULTICAIXA_EXPRESS("Multicaixa Express", "SERVICE_PAYMENT"),
    REFERENCE_PAYMENT("Pagamento por Referência", "SERVICE_PAYMENT"),
    SERVICE_PAYMENT("Pagamento de Serviço", "SERVICE_PAYMENT"),
    RUPE("RUPE - Estado", "SERVICE_PAYMENT"),
    TELECOM("Telecomunicações", "SERVICE_PAYMENT"),
    WATER("Água", "SERVICE_PAYMENT"),
    ENERGY("Energia", "SERVICE_PAYMENT"),
    INSURANCE("Seguros", "SERVICE_PAYMENT"),
    CREDIT_INSTALLMENT("Prestação de Crédito", "SERVICE_PAYMENT"),
    SAVINGS_DEPOSIT("Depósito Poupança", "TRANSFER");

    companion object {
        fun fromBackendString(raw: String?, description: String? = null): PaymentType {
            if (raw.isNullOrBlank()) return TRANSFER
            val normalized = raw.trim().uppercase()
            return try {
                valueOf(normalized)
            } catch (e: Exception) {
                when {
                    description?.contains("NOVA → NOVA", ignoreCase = true) == true -> NOVA_TO_NOVA
                    description?.contains("Multicaixa Express", ignoreCase = true) == true -> MULTICAIXA_EXPRESS
                    description?.contains("Referência", ignoreCase = true) == true -> REFERENCE_PAYMENT
                    normalized.contains("SERVICE") || normalized.contains("PAYMENT") -> SERVICE_PAYMENT
                    else -> TRANSFER
                }
            }
        }
    }
}

enum class TransferMethodCategory(val label: String) {
    NOVA_TO_NOVA("NOVA → NOVA"),
    BANK_TRANSFER("Conta Bancária"),
    MULTICAIXA_EXPRESS("Multicaixa Express"),
    REFERENCE_PAYMENT("Pagamento por Referência")
}

enum class NovaLookupSubMethod(val label: String) {
    PHONE("Telefone"),
    NOVA_ID("NOVA ID")
}

enum class BankTransferSubMethod(val label: String) {
    IBAN("IBAN"),
    ACCOUNT_NUMBER("Número de Conta")
}

enum class ReferencePaymentSubMethod(val label: String) {
    ENTITY_REFERENCE("Entidade e Referência")
}

enum class IntegrationAvailabilityStatus(val label: String, val badgeText: String) {
    ACTIVE_SANDBOX("Ativo (Sandbox)", "SANDBOX ATIVO"),
    PLANNED("Planeado", "PLANEADO"),
    NOT_AVAILABLE("Indisponível", "INDISPONÍVEL — AGUARDA PROVIDER")
}

data class AngolaBankProvider(
    val code: String,
    val shortName: String,
    val fullName: String,
    val ibanPrefix: String,
    val transferAvailability: IntegrationAvailabilityStatus = IntegrationAvailabilityStatus.PLANNED
)

object AngolaBanksCatalog {
    val banks: List<AngolaBankProvider> = listOf(
        AngolaBankProvider("0040", "BAI", "Banco Angolano de Investimentos (BAI)", "AO06.0040", IntegrationAvailabilityStatus.PLANNED),
        AngolaBankProvider("0006", "BFA", "Banco de Fomento Angola (BFA)", "AO06.0006", IntegrationAvailabilityStatus.PLANNED),
        AngolaBankProvider("0055", "BMA", "Banco Millennium Atlântico (BMA)", "AO06.0055", IntegrationAvailabilityStatus.PLANNED),
        AngolaBankProvider("0010", "BPC", "Banco de Poupança e Crédito (BPC)", "AO06.0010", IntegrationAvailabilityStatus.PLANNED),
        AngolaBankProvider("0051", "BIC", "Banco BIC", "AO06.0051", IntegrationAvailabilityStatus.PLANNED),
        AngolaBankProvider("0044", "SOL", "Banco Sol", "AO06.0044", IntegrationAvailabilityStatus.PLANNED),
        AngolaBankProvider("0060", "SBA", "Standard Bank Angola (SBA)", "AO06.0060", IntegrationAvailabilityStatus.PLANNED),
        AngolaBankProvider("0059", "BCA", "Banco Comercial Angolano (BCA)", "AO06.0059", IntegrationAvailabilityStatus.PLANNED)
    )

    fun findByCodeOrName(query: String): AngolaBankProvider? {
        val q = query.trim()
        return banks.find {
            it.code.equals(q, ignoreCase = true) ||
                it.shortName.equals(q, ignoreCase = true) ||
                it.fullName.equals(q, ignoreCase = true) ||
                it.fullName.contains(q, ignoreCase = true)
        }
    }
}

enum class PaymentProvider(val displayName: String) {
    BITPAY("BitPay"),
    INTELIZE("Intelize"),
    APPYPAY("AppyPay"),
    PAYPAY("PayPay"),
    BANK("Interbancário / EMIS")
}

enum class PaymentMethod(val code: String, val label: String, val isAvailableForConfig: Boolean) {
    MULTICAIXA_EXPRESS("MULTICAIXA_EXPRESS", "Multicaixa Express", true),
    REFERENCE_PAYMENT("REFERENCE_PAYMENT", "Referência Multicaixa", true),
    NOVA_TO_NOVA("NOVA_TO_NOVA", "NOVA → NOVA", true),
    IBAN("IBAN", "Transferência IBAN", true),
    UNITEL_MONEY("UNITEL_MONEY", "Unitel Money", false),
    KWIK("KWIK", "KWiK", false),
    DIRECT_DEBIT("DIRECT_DEBIT", "Débito Directo", false),
    INTERNATIONAL_CARDS("INTERNATIONAL_CARDS", "Cartões Internacionais", false)
}

enum class PaymentStatus(val label: String) {
    CREATED("Criado"),
    PENDING("Em processamento"),
    PROCESSING("A processar"),
    SUCCEEDED("Concluído"),
    FAILED("Falhou"),
    EXPIRED("Expirado"),
    CANCELLED("Cancelado"),
    REFUNDED("Reembolsado"),

    // Estados compatíveis com fluxos de autorização multi-etapa do backend
    DRAFT("Criado"),
    VALIDATED("Criado"),
    PENDING_AUTHORIZATION("Em processamento"),
    AUTHORIZED("A processar"),
    CONFIRMED("Concluído"),
    REJECTED("Falhou");

    fun isTerminal(): Boolean = this in listOf(
        SUCCEEDED, CONFIRMED, FAILED, EXPIRED, CANCELLED, REJECTED, REFUNDED
    )

    fun isSuccessful(): Boolean = this == SUCCEEDED || this == CONFIRMED

    fun canTransitionTo(target: PaymentStatus): Boolean {
        if (this == target) return true
        if (isTerminal() && !(this in listOf(SUCCEEDED, CONFIRMED) && target == REFUNDED)) return false

        return when (this) {
            CREATED, DRAFT -> target in listOf(
                VALIDATED, PENDING, PENDING_AUTHORIZATION, PROCESSING, CANCELLED, FAILED, REJECTED, EXPIRED
            )
            VALIDATED -> target in listOf(
                PENDING, PENDING_AUTHORIZATION, PROCESSING, CANCELLED, FAILED, REJECTED, EXPIRED
            )
            PENDING, PENDING_AUTHORIZATION -> target in listOf(
                AUTHORIZED, PROCESSING, SUCCEEDED, CONFIRMED, CANCELLED, REJECTED, FAILED, EXPIRED
            )
            AUTHORIZED -> target in listOf(
                PROCESSING, SUCCEEDED, CONFIRMED, FAILED, CANCELLED, REJECTED, EXPIRED
            )
            PROCESSING -> target in listOf(
                SUCCEEDED, CONFIRMED, FAILED, REJECTED, EXPIRED, CANCELLED
            )
            SUCCEEDED, CONFIRMED -> target == REFUNDED
            FAILED, EXPIRED, CANCELLED, REJECTED, REFUNDED -> false
        }
    }

    companion object {
        fun fromBackendString(raw: String?): PaymentStatus {
            if (raw.isNullOrBlank()) return CREATED
            return when (raw.trim().uppercase()) {
                "CREATED" -> CREATED
                "PENDING", "AWAITING_CONFIRMATION" -> PENDING
                "PENDING_AUTHORIZATION", "AWAITING_AUTHORIZATION" -> PENDING_AUTHORIZATION
                "AUTHORIZED", "APPROVED" -> AUTHORIZED
                "PROCESSING", "IN_PROGRESS" -> PROCESSING
                "SUCCEEDED" -> SUCCEEDED
                "COMPLETED", "CONFIRMED", "SUCCESS", "EXECUTED", "PAID" -> CONFIRMED
                "VALIDATED" -> VALIDATED
                "FAILED", "ERROR" -> FAILED
                "EXPIRED", "TIMEOUT" -> EXPIRED
                "CANCELLED", "CANCELED" -> CANCELLED
                "REFUNDED", "REVERSED" -> REFUNDED
                "REJECTED", "DECLINED" -> REJECTED
                "DRAFT" -> DRAFT
                else -> try { valueOf(raw.trim().uppercase()) } catch (e: Exception) { CREATED }
            }
        }
    }
}

enum class AuthMethod(val label: String, val description: String) {
    APP("NOVA KZ App", "Autorização instantânea através do aplicativo (Recomendado para Sandbox)"),
    MCX_EXPRESS("Multicaixa Express", "Confirmação via notificação MCX Express"),
    OTP("SMS / OTP", "Código numérico temporário enviado por SMS"),
    THREE_DS("3D Secure", "Autenticação adicional segura para cartões"),
    BANK("Internet Banking", "Validação no portal da instituição bancária"),
    OTHER("Outro Método", "Validação através de token de segurança externo")
}

data class PaymentOperation(
    val id: String = UUID.randomUUID().toString(),
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val type: PaymentType,
    val amount: Double,
    val currency: String = "AOA",
    val beneficiary: String,
    val beneficiaryAccount: String? = null,
    val reference: String? = null,
    val description: String,
    val status: PaymentStatus = PaymentStatus.DRAFT,
    val authMethod: AuthMethod = AuthMethod.APP,
    val environment: String = "SANDBOX",
    val createdAt: String = "",
    val completedAt: String? = null,
    val fee: Double = 0.0,
    val transactionId: String = "NKZ-" + System.currentTimeMillis().toString().takeLast(8),
    val failureReason: String? = null,
    val provider: PaymentProvider? = null
)

typealias PaymentTransaction = PaymentOperation

sealed class PaymentResult<out T> {
    data class Success<T>(val data: T, val status: PaymentStatus) : PaymentResult<T>()
    data class Failure(val message: String, val code: Int? = null, val isRetryable: Boolean = true) : PaymentResult<Nothing>()
}

data class NovaRecipient(
    val phone: String,
    val displayName: String,
    val active: Boolean = true,
    val novaId: String = phone
)

object PhoneUtils {
    fun normalizeAngolaPhone(raw: String): String {
        val trimmed = raw.trim()
        val cleaned = trimmed.replace(Regex("[\\s\\-\\(\\)\\.]"), "")
        return when {
            cleaned.startsWith("+244") -> cleaned
            cleaned.startsWith("00244") -> "+244" + cleaned.removePrefix("00244")
            cleaned.startsWith("244") && cleaned.length >= 11 -> "+$cleaned"
            cleaned.length == 9 && cleaned.startsWith("9") -> "+244$cleaned"
            cleaned.startsWith("+") -> cleaned
            cleaned.isNotBlank() -> if (cleaned.length == 9) "+244$cleaned" else "+$cleaned"
            else -> ""
        }
    }

    fun normalizeNovaIdentifier(raw: String, subMethod: NovaLookupSubMethod = NovaLookupSubMethod.PHONE): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return ""
        return when (subMethod) {
            NovaLookupSubMethod.PHONE -> normalizeAngolaPhone(trimmed)
            NovaLookupSubMethod.NOVA_ID -> {
                val upper = trimmed.uppercase().replace(" ", "")
                when {
                    upper.startsWith("NOVA-") || upper.startsWith("NKZ-") || upper.startsWith("@") -> trimmed.replace(" ", "")
                    trimmed.all { it.isDigit() || it in "+-() ." } -> normalizeAngolaPhone(trimmed)
                    else -> trimmed
                }
            }
        }
    }

    fun formatDisplayPhone(phone: String): String {
        val normalized = normalizeAngolaPhone(phone)
        val digits = normalized.removePrefix("+")
        return if (digits.startsWith("244") && digits.length == 12) {
            val p1 = digits.substring(0, 3)
            val p2 = digits.substring(3, 6)
            val p3 = digits.substring(6, 9)
            val p4 = digits.substring(9, 12)
            "+$p1 $p2 $p3 $p4"
        } else {
            normalized
        }
    }
}
