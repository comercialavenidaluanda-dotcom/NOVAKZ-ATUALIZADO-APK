package com.example.domain.legal

object LegalConstants {
    const val CURRENT_TERMS_VERSION = "1.0"
    const val CURRENT_PRIVACY_VERSION = "1.2"
    const val LAST_UPDATED_DATE = "24 de Setembro de 2026"
    const val JURISDICTION = "República de Angola (Luanda)"
    const val TERMS_URL = "https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-terms"
    const val PRIVACY_URL = "https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-privacy"
    const val ACCOUNT_DELETION_URL = "https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-account-deletion"
    const val SUPPORT_EMAIL = "ivanioalberto83@gmail.com"
    const val SUPPORT_WHATSAPP = "+244 946 110 370"
    const val SUPPORT_PHONE = "+244 946 110 370"
}

enum class AppLegalAuthState {
    UNAUTHENTICATED,
    LEGAL_ACCEPTANCE_REQUIRED,
    AUTHENTICATED_AND_LEGAL_ACCEPTED
}

data class LegalAcceptanceRecord(
    val id: String = "",
    val userId: String,
    val termsVersion: String,
    val privacyVersion: String,
    val acceptedTerms: Boolean,
    val acceptedPrivacy: Boolean,
    val acceptedAt: String = "",
    val createdAt: String = "",
    val updatedAt: String = ""
)
