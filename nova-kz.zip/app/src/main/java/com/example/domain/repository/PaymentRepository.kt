package com.example.domain.repository

import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import java.util.UUID

/**
 * Repositório normalizado de pagamentos do NOVA KZ.
 * Assegura que a camada de apresentação não converse diretamente com tabelas financeiras,
 * delegando todas as operações aos RPCs/Edge Functions autorizados no backend Supabase.
 */
interface PaymentRepository {

    suspend fun createPayment(
        type: PaymentType,
        amount: Double,
        beneficiary: String,
        description: String,
        beneficiaryAccount: String? = null,
        reference: String? = null,
        authMethod: AuthMethod = AuthMethod.APP,
        idempotencyKey: String = UUID.randomUUID().toString()
    ): NetworkResult<PaymentOperation>

    suspend fun getPayment(id: String): PaymentOperation?

    suspend fun getPaymentHistory(): List<PaymentOperation>

    suspend fun retryPayment(
        operationId: String,
        preservedIdempotencyKey: String? = null
    ): NetworkResult<PaymentOperation>
}

class DefaultPaymentRepository(
    private val paymentManager: PaymentManager
) : PaymentRepository {

    override suspend fun createPayment(
        type: PaymentType,
        amount: Double,
        beneficiary: String,
        description: String,
        beneficiaryAccount: String?,
        reference: String?,
        authMethod: AuthMethod,
        idempotencyKey: String
    ): NetworkResult<PaymentOperation> {
        return paymentManager.createPaymentOperation(
            type = type,
            amount = amount,
            beneficiary = beneficiary,
            description = description,
            beneficiaryAccount = beneficiaryAccount,
            reference = reference,
            authMethod = authMethod,
            idempotencyKey = idempotencyKey
        )
    }

    override suspend fun getPayment(id: String): PaymentOperation? {
        return paymentManager.getOperationById(id)
    }

    override suspend fun getPaymentHistory(): List<PaymentOperation> {
        paymentManager.loadMyPaymentOperations()
        return paymentManager.operations.value
    }

    override suspend fun retryPayment(
        operationId: String,
        preservedIdempotencyKey: String?
    ): NetworkResult<PaymentOperation> {
        val existing = paymentManager.getOperationById(operationId)
            ?: return NetworkResult.Error("Operação não encontrada para repetição segura.")

        val keyToUse = preservedIdempotencyKey ?: existing.idempotencyKey
        return paymentManager.createPaymentOperation(
            type = existing.type,
            amount = existing.amount,
            beneficiary = existing.beneficiary,
            description = existing.description,
            beneficiaryAccount = existing.beneficiaryAccount,
            reference = existing.reference,
            authMethod = existing.authMethod,
            idempotencyKey = keyToUse
        )
    }
}
