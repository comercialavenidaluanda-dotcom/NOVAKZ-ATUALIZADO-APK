package com.example.auth

import android.content.Context
import com.example.data.LocalDataStore
import com.example.domain.models.UserProfile
import com.example.network.NetworkResult
import com.example.network.SupabaseRestClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

class AuthManager(
    private val dataStore: LocalDataStore,
    private val restClient: SupabaseRestClient,
    private val onFcmDeactivate: (suspend (String) -> Unit)? = null
) {
    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    init {
        // Check if there is an existing session
        if (dataStore.hasActiveSession()) {
            _currentUser.value = loadSavedProfile()
            _isAuthenticated.value = true
        }
    }

    suspend fun ensureValidSession(): Boolean {
        val token = dataStore.authToken
        val refresh = dataStore.refreshToken
        if (token.isNullOrBlank() && refresh.isNullOrBlank()) {
            return false
        }
        if (token != null && token.startsWith("nkz_sandbox_token_")) {
            return true
        }
        if ((token.isNullOrBlank() || dataStore.isTokenExpired()) && !refresh.isNullOrBlank()) {
            val res = restClient.refreshSession(refresh)
            if (res is NetworkResult.Success) {
                return true
            }
        }
        return !dataStore.authToken.isNullOrBlank()
    }

    private fun loadSavedProfile(): UserProfile {
        val isSandbox = isSandboxEmail(dataStore.userEmail) || dataStore.userId == SANDBOX_USER_ID
        return UserProfile(
            id = dataStore.userId,
            name = if (dataStore.userName.isNotBlank()) dataStore.userName else if (isSandbox) "Utilizador Sandbox (NOVA KZ)" else "Utilizador NOVA KZ",
            email = dataStore.userEmail,
            phone = dataStore.userPhone,
            nif = "005928172LA041",
            kycLevel = if (isSandbox) "Nível 2 (Verificado - Sandbox)" else "Nível 1 (Conta Real)",
            isSandboxMode = isSandbox,
            biometricsEnabled = dataStore.isBiometricsEnabled,
            appPinConfigured = dataStore.hasAppPin(),
            inactivityTimeoutMinutes = dataStore.inactivityTimeoutMinutes
        )
    }

    suspend fun login(email: String, pinOrPassword: String): NetworkResult<UserProfile> {
        val trimmedEmail = email.trim()
        if (trimmedEmail.isBlank() || pinOrPassword.isBlank()) {
            return NetworkResult.Error("Preencha o e-mail e a palavra-passe ou PIN.")
        }

        // Try real Supabase Authentication first if configured and not the dedicated local demo account
        val isDedicatedLocalDemo = trimmedEmail.equals(SANDBOX_EMAIL, ignoreCase = true)
        if (!isDedicatedLocalDemo && restClient.isConfigured()) {
            when (val authResult = restClient.signInWithPassword(trimmedEmail, pinOrPassword)) {
                is NetworkResult.Success -> {
                    val json = authResult.data
                    val accessToken = json.optString("access_token", "")
                    val refreshToken = json.optString("refresh_token", "")
                    val expiresIn = json.optLong("expires_in", 3600L)
                    if (accessToken.isNotBlank()) {
                        val userObj = json.optJSONObject("user")
                        val realUserId = userObj?.optString("id", "") ?: UUID.randomUUID().toString()
                        val userMetadata = userObj?.optJSONObject("user_metadata")
                        val resolvedName = userMetadata?.optString("name", "")?.ifBlank { null }
                            ?: dataStore.userName.ifBlank { "Utilizador NOVA KZ" }
                        val resolvedPhone = userMetadata?.optString("phone", "")?.ifBlank { null }
                            ?: dataStore.userPhone
                        val resolvedNif = userMetadata?.optString("nif", "")?.ifBlank { null }
                            ?: "005928172LA041"

                        dataStore.userId = realUserId
                        dataStore.saveSession(
                            accessToken = accessToken,
                            newRefreshToken = refreshToken.ifBlank { null },
                            expiresInSeconds = expiresIn
                        )
                        dataStore.userEmail = trimmedEmail
                        dataStore.userName = resolvedName
                        if (resolvedPhone.isNotBlank()) {
                            dataStore.userPhone = resolvedPhone
                        }

                        val profile = UserProfile(
                            id = realUserId,
                            name = resolvedName,
                            email = trimmedEmail,
                            phone = resolvedPhone,
                            nif = resolvedNif,
                            kycLevel = "Nível 2 (Verificado - Sandbox)",
                            isSandboxMode = true,
                            biometricsEnabled = dataStore.isBiometricsEnabled,
                            appPinConfigured = dataStore.hasAppPin(),
                            inactivityTimeoutMinutes = dataStore.inactivityTimeoutMinutes
                        )

                        _currentUser.value = profile
                        _isAuthenticated.value = true

                        dataStore.fcmToken?.let { token ->
                            restClient.upsertDeviceToken(profile.id, token, "android")
                        }

                        return NetworkResult.Success(profile)
                    }
                }
                is NetworkResult.Error -> {
                    // If it's NOT a sandbox fallback email, return the real Supabase error
                    if (!isSandboxEmail(trimmedEmail)) {
                        return NetworkResult.Error(authResult.message, code = authResult.code)
                    }
                }
            }
        }

        // Demo / Sandbox Account Handling (Isolated environment or fallback)
        if (isSandboxEmail(trimmedEmail)) {
            if (pinOrPassword.length < 4) {
                return NetworkResult.Error("O PIN ou palavra-passe deve conter pelo menos 4 dígitos.")
            }

            val resolvedUserId = when {
                trimmedEmail.equals(SANDBOX_EMAIL, ignoreCase = true) -> SANDBOX_USER_ID
                trimmedEmail.equals(TEST_SANDBOX_EMAIL, ignoreCase = true) -> SANDBOX_USER_ID
                trimmedEmail.equals(ALT_SANDBOX_EMAIL, ignoreCase = true) -> SANDBOX_USER_ID
                else -> "usr_sandbox_" + trimmedEmail.lowercase().replace(Regex("[^a-z0-9]"), "_")
            }

            dataStore.userId = resolvedUserId
            dataStore.saveSession(
                accessToken = "nkz_sandbox_token_" + UUID.randomUUID().toString(),
                newRefreshToken = null,
                expiresInSeconds = 86400L * 30
            )
            dataStore.userEmail = trimmedEmail
            if (dataStore.userName.isBlank()) {
                dataStore.userName = when {
                    trimmedEmail.contains("avenida") -> "Comercial Avenida"
                    trimmedEmail.contains("ivanio") -> "Ivânio Alberto"
                    else -> "Utilizador Sandbox (NOVA KZ)"
                }
            }

            val profile = UserProfile(
                id = resolvedUserId,
                name = dataStore.userName,
                email = trimmedEmail,
                phone = dataStore.userPhone.ifBlank { "+244 923 000 000" },
                nif = "005928172LA041",
                kycLevel = "Nível 2 (Verificado - Sandbox)",
                isSandboxMode = true,
                biometricsEnabled = dataStore.isBiometricsEnabled,
                appPinConfigured = dataStore.hasAppPin(),
                inactivityTimeoutMinutes = dataStore.inactivityTimeoutMinutes
            )

            _currentUser.value = profile
            _isAuthenticated.value = true

            dataStore.fcmToken?.let { token ->
                restClient.upsertDeviceToken(profile.id, token, "android")
            }

            return NetworkResult.Success(profile)
        }

        // Real Supabase Authentication when not configured
        return NetworkResult.Error(
            "Configuração do Supabase ausente. Defina a chave SUPABASE_ANON_KEY no painel de segredos para autenticar contas reais, ou aceda através da conta Sandbox/Demonstração.",
            code = 503
        )
    }

    fun loginWithBiometrics(): Boolean {
        val existingToken = dataStore.authToken
        if (existingToken.isNullOrBlank()) {
            if (isSandboxEmail(dataStore.userEmail) || dataStore.userId == SANDBOX_USER_ID) {
                dataStore.authToken = "nkz_sandbox_token_" + UUID.randomUUID().toString()
                dataStore.isBiometricsEnabled = true
            } else {
                return false
            }
        }
        _currentUser.value = loadSavedProfile()
        _isAuthenticated.value = true
        return true
    }

    suspend fun register(
        name: String,
        email: String,
        phone: String,
        nif: String,
        pin: String
    ): NetworkResult<UserProfile> {
        val trimmedEmail = email.trim()
        if (name.isBlank() || trimmedEmail.isBlank() || phone.isBlank() || pin.length < 4) {
            return NetworkResult.Error("Por favor, preencha todos os campos obrigatórios (PIN/palavra-passe mínimo 4 dígitos).")
        }

        if (isSandboxEmail(trimmedEmail)) {
            dataStore.userName = name
            dataStore.userEmail = trimmedEmail
            dataStore.userPhone = phone
            dataStore.setAppPin(pin)
            dataStore.userId = SANDBOX_USER_ID
            dataStore.authToken = "nkz_sandbox_token_" + UUID.randomUUID().toString()

            val profile = UserProfile(
                id = SANDBOX_USER_ID,
                name = name,
                email = trimmedEmail,
                phone = phone,
                nif = nif.ifBlank { "005928172LA041" },
                kycLevel = "Nível 2 (Verificado - Sandbox)",
                isSandboxMode = true,
                biometricsEnabled = false,
                appPinConfigured = true,
                inactivityTimeoutMinutes = 3
            )

            _currentUser.value = profile
            _isAuthenticated.value = true
            return NetworkResult.Success(profile)
        }

        if (!restClient.isConfigured()) {
            return NetworkResult.Error("Configuração do Supabase ausente. Defina a SUPABASE_ANON_KEY no painel de segredos para registrar novas contas reais.", code = 503)
        }

        val metadata = mapOf(
            "name" to name,
            "phone" to phone,
            "nif" to nif.ifBlank { "005928172LA041" }
        )

        when (val result = restClient.signUpWithPassword(trimmedEmail, pin, metadata)) {
            is NetworkResult.Success -> {
                val json = result.data
                val accessToken = json.optString("access_token", "")
                val refreshToken = json.optString("refresh_token", "")
                val expiresIn = json.optLong("expires_in", 3600L)
                val userObj = json.optJSONObject("user")
                val realUserId = userObj?.optString("id", "") ?: UUID.randomUUID().toString()

                dataStore.userName = name
                dataStore.userEmail = trimmedEmail
                dataStore.userPhone = phone
                dataStore.setAppPin(pin)
                dataStore.userId = realUserId
                if (accessToken.isNotBlank()) {
                    dataStore.saveSession(accessToken, refreshToken.ifBlank { null }, expiresIn)
                } else {
                    dataStore.authToken = null
                }

                val profile = UserProfile(
                    id = realUserId,
                    name = name,
                    email = trimmedEmail,
                    phone = phone,
                    nif = nif.ifBlank { "005928172LA041" },
                    kycLevel = "Nível 1 (Conta Real)",
                    isSandboxMode = false,
                    biometricsEnabled = false,
                    appPinConfigured = true,
                    inactivityTimeoutMinutes = 3
                )

                if (accessToken.isNotBlank()) {
                    _currentUser.value = profile
                    _isAuthenticated.value = true
                }

                return NetworkResult.Success(profile)
            }
            is NetworkResult.Error -> {
                return NetworkResult.Error(result.message, code = result.code)
            }
        }
    }

    suspend fun recoverAccess(identifier: String): NetworkResult<String> {
        val trimmed = identifier.trim()
        if (trimmed.isBlank()) {
            return NetworkResult.Error("Introduza o seu e-mail ou número de telefone registado.")
        }

        if (isSandboxEmail(trimmed)) {
            return NetworkResult.Success("Conta Sandbox: O PIN de demonstração padrão é 1234.")
        }

        if (trimmed.contains("@") && restClient.isConfigured()) {
            when (val res = restClient.resetPasswordForEmail(trimmed)) {
                is NetworkResult.Success -> {
                    return NetworkResult.Success("Enviámos uma ligação de recuperação de acesso para $trimmed.")
                }
                is NetworkResult.Error -> {
                    return NetworkResult.Error(res.message, code = res.code)
                }
            }
        }

        return NetworkResult.Success(
            "Enviámos instruções seguras para recuperação de acesso para $trimmed. Verifique também o seu SMS/Email."
        )
    }

    fun logout() {
        val currentToken = dataStore.fcmToken
        if (currentToken != null) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    restClient.deactivateDeviceToken(currentToken)
                    onFcmDeactivate?.invoke(currentToken)
                } catch (e: Exception) {
                    // Ignore failure on logout
                }
            }
        }
        dataStore.clearSession()
        _currentUser.value = null
        _isAuthenticated.value = false
    }

    fun updateProfile(updated: UserProfile) {
        _currentUser.value = updated
        dataStore.userName = updated.name
        dataStore.userEmail = updated.email
        dataStore.userPhone = updated.phone
        dataStore.isBiometricsEnabled = updated.biometricsEnabled
        dataStore.inactivityTimeoutMinutes = updated.inactivityTimeoutMinutes
    }

    companion object {
        const val SANDBOX_USER_ID = "usr_novakz_sandbox_01"
        const val SANDBOX_EMAIL = "sandbox@novakz.ao"
        const val TEST_SANDBOX_EMAIL = "comercialavenidaluanda@gmail.com"
        const val ALT_SANDBOX_EMAIL = "ivanioalberto83@gmail.com"

        fun isSandboxEmail(email: String?): Boolean {
            if (email.isNullOrBlank()) return false
            val trimmed = email.trim()
            return trimmed.equals(SANDBOX_EMAIL, ignoreCase = true) ||
                    trimmed.equals(TEST_SANDBOX_EMAIL, ignoreCase = true) ||
                    trimmed.equals(ALT_SANDBOX_EMAIL, ignoreCase = true) ||
                    trimmed.endsWith("@novakz.ao") ||
                    trimmed.contains("sandbox") ||
                    trimmed.contains("teste") ||
                    trimmed.contains("demo") ||
                    trimmed.contains("exemplo.ao")
        }
    }
}
