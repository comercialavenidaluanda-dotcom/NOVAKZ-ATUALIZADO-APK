package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.LocalDataStore
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.network.SupabaseRestClient
import com.example.payments.PaymentManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PaymentSandboxFlowTest {

    private lateinit var dataStore: LocalDataStore
    private lateinit var restClient: SupabaseRestClient
    private lateinit var paymentManager: PaymentManager

    private var backendWalletBalance = 1000.0
    private val backendOperations = mutableMapOf<String, Double>()

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        dataStore = LocalDataStore(context)
        dataStore.saveSession(accessToken = "jwt_test_session_token", newRefreshToken = "refresh_test_token")
        backendWalletBalance = 1000.0
        backendOperations.clear()
        backendOperations["op_init_02"] = 200.0

        restClient = SupabaseRestClient { dataStore.authToken }
        restClient.rpcHandler = { functionName, params ->
            when (functionName) {
                "nova_kz_get_sandbox_balance" -> {
                    NetworkResult.Success("""{"ok":true,"balance":$backendWalletBalance,"wallet_initialized":true}""")
                }
                "nova_kz_create_payment_operation" -> {
                    val opId = "op_" + java.util.UUID.randomUUID().toString().take(8)
                    val amt = params.optDouble("p_amount", 0.0)
                    backendOperations[opId] = amt
                    NetworkResult.Success("""{"ok":true,"operation_id":"$opId","status":"PENDING_AUTHORIZATION"}""")
                }
                "nova_kz_authorize_payment_operation" -> {
                    val opId = params.optString("p_operation_id", "")
                    NetworkResult.Success("""{"ok":true,"operation_id":"$opId","status":"AUTHORIZED"}""")
                }
                "nova_kz_execute_sandbox_payment" -> {
                    val opId = params.optString("p_operation_id", "")
                    val amt = backendOperations[opId] ?: 0.0
                    if (amt > backendWalletBalance) {
                        NetworkResult.Error("INSUFFICIENT_FUNDS", code = 400)
                    } else {
                        backendWalletBalance -= amt
                        NetworkResult.Success("""{"ok":true,"operation_id":"$opId","status":"COMPLETED","new_balance":$backendWalletBalance}""")
                    }
                }
                "nova_kz_transition_payment" -> {
                    NetworkResult.Success("""{"ok":true}""")
                }
                "nova_kz_lookup_nova_id" -> {
                    val phone = params.optString("p_phone", "")
                    if (phone.contains("946110370")) {
                        NetworkResult.Success("""{"phone":"+244946110370","display_name":"Manuel Bento da Silva","active":true,"nova_id":"NOVA-946110370"}""")
                    } else if (phone.contains("924111222")) {
                        NetworkResult.Success("""{"phone":"+244924111222","display_name":"Ana Paula Kiala","active":true,"nova_id":"NOVA-924111222"}""")
                    } else if (phone.contains("999000111")) {
                        NetworkResult.Error("RECIPIENT_NOT_FOUND", code = 404)
                    } else {
                        NetworkResult.Success("""{"phone":"$phone","display_name":"Utilizador NOVA","active":true,"nova_id":"NOVA-${phone.removePrefix("+244")}"}""")
                    }
                }
                "nova_kz_send_to_nova" -> {
                    val amt = params.optDouble("p_amount", 0.0)
                    if (amt > backendWalletBalance) {
                        NetworkResult.Error("INSUFFICIENT_FUNDS", code = 400)
                    } else {
                        backendWalletBalance -= amt
                        val opId = "op_nova_" + java.util.UUID.randomUUID().toString().take(8)
                        NetworkResult.Success("""{"ok":true,"operation_id":"$opId","status":"COMPLETED","new_balance":$backendWalletBalance}""")
                    }
                }
                else -> NetworkResult.Success("{}")
            }
        }
        paymentManager = PaymentManager(dataStore, restClient)
        runBlocking {
            paymentManager.loadSandboxBalance()
        }
    }

    @Test
    fun testMandatorySandbox200AoaPaymentFlow() = runBlocking {
        // 1. Validar Saldo Inicial = 1.000 AOA
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // 2. Criar Pagamento de 200 AOA
        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.SERVICE_PAYMENT,
            amount = 200.0,
            beneficiary = "ENDE - E.P.",
            description = "Recarga Energia Pré-Pago",
            reference = "99827182918",
            authMethod = AuthMethod.APP
        )

        assertTrue(createResult is NetworkResult.Success)
        val createdOp = (createResult as NetworkResult.Success).data
        assertEquals(200.0, createdOp.amount, 0.001)
        assertEquals(PaymentStatus.PENDING_AUTHORIZATION, createdOp.status)
        assertNotNull(createdOp.idempotencyKey)

        // 3. Autorizar Operação com APP / Biometria
        val authResult = paymentManager.authorizePaymentOperation(
            operationId = createdOp.id,
            authMethod = AuthMethod.APP
        )

        assertTrue(authResult is NetworkResult.Success)
        val authorizedOp = (authResult as NetworkResult.Success).data
        assertEquals(PaymentStatus.AUTHORIZED, authorizedOp.status)

        // 4. Executar Sandbox e Confirmar
        val confirmResult = paymentManager.processAndConfirmPayment(authorizedOp.id)
        assertTrue(confirmResult is NetworkResult.Success)
        val confirmedOp = (confirmResult as NetworkResult.Success).data
        assertEquals(PaymentStatus.CONFIRMED, confirmedOp.status)
        assertNotNull(confirmedOp.completedAt)

        // 5. Validar Saldo Final = 800 AOA (1.000 - 200 = 800 AOA)
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
        assertEquals(800.0, dataStore.sandboxBalance, 0.001)

        // 6. Teste de Idempotência: Repetir execução da mesma operação NÃO deve debitar novamente
        val duplicateAttempt = paymentManager.processAndConfirmPayment(confirmedOp.id)
        assertTrue("Execução duplicada deve ser rejeitada", duplicateAttempt is NetworkResult.Error)
        // Saldo permanece 800 AOA
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testInsufficientBalanceRejection() = runBlocking {
        // Saldo inicial: 1000 AOA
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // Tentar pagamento de 1.500 AOA (superior ao saldo)
        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.TRANSFER,
            amount = 1500.0,
            beneficiary = "Manuel dos Santos",
            description = "Transferência Inválida"
        )
        val createdOp = (createResult as NetworkResult.Success).data

        // Autorizar
        paymentManager.authorizePaymentOperation(createdOp.id)

        // Executar deve falhar por falta de saldo
        val confirmResult = paymentManager.processAndConfirmPayment(createdOp.id)
        assertTrue(confirmResult is NetworkResult.Error)

        // Saldo não pode sofrer alteração
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testUnauthorizedExecutionRejection() = runBlocking {
        // Criar operação
        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.SERVICE_PAYMENT,
            amount = 200.0,
            beneficiary = "EPAL",
            description = "Conta de Água"
        )
        val createdOp = (createResult as NetworkResult.Success).data

        // Tentar executar sem antes autorizar
        val confirmResult = paymentManager.processAndConfirmPayment(createdOp.id)
        assertTrue("Operação não autorizada deve ser rejeitada", confirmResult is NetworkResult.Error)
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testRoomDatabasePersistenceAndOfflineInstantLoad() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val inMemoryDb = androidx.room.Room.inMemoryDatabaseBuilder(
            context,
            com.example.data.local.NovaKzDatabase::class.java
        ).allowMainThreadQueries().build()

        val repository = com.example.data.repository.PaymentTransactionRepository(
            transactionDao = inMemoryDb.paymentTransactionDao(),
            restClient = restClient
        )

        val roomBackedManager = PaymentManager(
            dataStore = dataStore,
            restClient = restClient,
            transactionRepository = repository
        )

        // Criar pagamento com persistência Room
        val opResult = roomBackedManager.createPaymentOperation(
            type = PaymentType.RUPE,
            amount = 350.0,
            beneficiary = "Ministério das Finanças",
            description = "Taxa Aduaneira RUPE",
            reference = "99482718291"
        )
        assertTrue(opResult is NetworkResult.Success)
        val op = (opResult as NetworkResult.Success).data

        // Autorizar e Confirmar
        roomBackedManager.authorizePaymentOperation(op.id)
        roomBackedManager.processAndConfirmPayment(op.id)

        // Validar que o registro está gravado diretamente na tabela Room 'nova_kz_payment_transactions'
        val entityInDb = inMemoryDb.paymentTransactionDao().getTransactionById(op.id)
        assertNotNull("Transação deve estar persistida no Room", entityInDb)
        assertEquals(op.id, entityInDb?.id)
        assertEquals(350.0, entityInDb?.amount ?: 0.0, 0.001)
        assertEquals("CONFIRMED", entityInDb?.status)

        inMemoryDb.close()
    }

    @Test
    fun testNovaToNovaLookupAndSendByPhoneNumber() = runBlocking {
        // 1. Validar Saldo Inicial
        dataStore.sandboxBalance = 1000.0
        paymentManager.setSandboxBalance(1000.0)

        // 2. Pesquisa de Destinatário por Número de Telefone (+244 946 110 370)
        val lookupResult = paymentManager.lookupNovaRecipient("+244 946 110 370")
        assertTrue("Lookup deve ser bem-sucedido para número angolano válido", lookupResult is NetworkResult.Success)
        val recipient = (lookupResult as NetworkResult.Success).data
        assertEquals("+244946110370", recipient.phone)
        assertTrue(recipient.displayName.isNotBlank())
        assertTrue(recipient.active)

        // 3. Execução de Transferência NOVA -> NOVA (150 AOA)
        val idempotencyKey = java.util.UUID.randomUUID().toString()
        val sendResult = paymentManager.sendToNova(
            recipientPhone = recipient.phone,
            amount = 150.0,
            description = "Pagamento almoço",
            idempotencyKey = idempotencyKey,
            recipientName = recipient.displayName
        )

        assertTrue("Transferência deve ser concluída com sucesso", sendResult is NetworkResult.Success)
        val confirmedOp = (sendResult as NetworkResult.Success).data
        assertEquals(150.0, confirmedOp.amount, 0.001)
        assertEquals(PaymentStatus.CONFIRMED, confirmedOp.status)
        assertEquals("NOVA → NOVA", confirmedOp.description)
        assertTrue(confirmedOp.reference?.startsWith("NOVA-") == true)
        assertEquals("+244946110370", confirmedOp.beneficiaryAccount)

        // 4. Validar Dedução de Saldo (1.000 - 150 = 850 AOA)
        assertEquals(850.0, paymentManager.sandboxBalance.value, 0.001)

        // 5. Validar Idempotência: repetir chamada com mesma idempotencyKey NÃO deduz novamente
        val duplicateResult = paymentManager.sendToNova(
            recipientPhone = recipient.phone,
            amount = 150.0,
            description = "Pagamento almoço",
            idempotencyKey = idempotencyKey,
            recipientName = recipient.displayName
        )
        assertTrue(duplicateResult is NetworkResult.Success)
        assertEquals(850.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testNovaToNovaSelfTransferAndInsufficientFundsValidation() = runBlocking {
        dataStore.sandboxBalance = 500.0
        dataStore.userPhone = "+244 923 000 000"
        paymentManager.setSandboxBalance(500.0)

        // Tentativa de auto-transferência
        val selfResult = paymentManager.sendToNova(
            recipientPhone = "+244 923 000 000",
            amount = 100.0,
            idempotencyKey = java.util.UUID.randomUUID().toString()
        )
        assertTrue(selfResult is NetworkResult.Error)
        assertEquals("Não podes enviar dinheiro para o teu próprio número.", (selfResult as NetworkResult.Error).message)

        // Tentativa de transferência com saldo insuficiente
        val excessiveResult = paymentManager.sendToNova(
            recipientPhone = "+244 946 110 370",
            amount = 600.0,
            idempotencyKey = java.util.UUID.randomUUID().toString()
        )
        assertTrue(excessiveResult is NetworkResult.Error)
        assertEquals("Saldo insuficiente para concluir esta transferência.", (excessiveResult as NetworkResult.Error).message)
    }

    @Test
    fun testNovaToNovaLookupByNovaId() = runBlocking {
        val lookupResult = paymentManager.lookupNovaRecipient(
            phone = "NOVA-946110370",
            subMethod = com.example.domain.models.NovaLookupSubMethod.NOVA_ID
        )
        assertTrue("Lookup por NOVA ID deve ser bem-sucedido", lookupResult is NetworkResult.Success)
        val recipient = (lookupResult as NetworkResult.Success).data
        assertEquals("+244946110370", recipient.phone)
        assertEquals("NOVA-946110370", recipient.novaId)
        assertTrue(recipient.displayName.isNotBlank())
    }

    @Test
    fun testBankTransferIbanAndAccountNumberPlannedStatusNeverSimulated() = runBlocking {
        dataStore.sandboxBalance = 1000.0
        paymentManager.setSandboxBalance(1000.0)

        // 1. Validar IBAN com banco BAI (PLANNED - sem provider bancário ativo)
        val ibanValidation = paymentManager.validateBankTransferRequest(
            subMethod = com.example.domain.models.BankTransferSubMethod.IBAN,
            bankCodeOrName = "0040",
            ibanOrAccount = "AO06.0040.0000.7788.9900.1122.3",
            accountHolder = "Manuel Bento",
            amount = 250.0,
            description = "Transferência IBAN"
        )
        assertEquals(false, ibanValidation.canExecute)
        assertEquals(
            com.example.domain.models.IntegrationAvailabilityStatus.PLANNED,
            ibanValidation.availabilityStatus
        )
        // Saldo nunca deve ser alterado porque transferências bancárias sem provider não são simuladas
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // 2. Validar Número de Conta com banco BFA (PLANNED - sem provider bancário ativo)
        val accountValidation = paymentManager.validateBankTransferRequest(
            subMethod = com.example.domain.models.BankTransferSubMethod.ACCOUNT_NUMBER,
            bankCodeOrName = "0006",
            ibanOrAccount = "82910291101",
            accountHolder = "Manuel Bento",
            amount = 300.0,
            description = "Transferência Número de Conta"
        )
        assertEquals(false, accountValidation.canExecute)
        assertEquals(
            com.example.domain.models.IntegrationAvailabilityStatus.PLANNED,
            accountValidation.availabilityStatus
        )
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testReferencePaymentValidationAndMulticaixaExpressFlow() = runBlocking {
        dataStore.sandboxBalance = 1000.0
        paymentManager.setSandboxBalance(1000.0)

        // 1. Validar Entidade e Referência (ENDE 00201)
        val refValidation = paymentManager.validateReferencePayment(
            entityInput = "00201",
            referenceInput = "1002938491",
            amount = 150.0
        )
        assertTrue(refValidation is NetworkResult.Success)
        val refInfo = (refValidation as NetworkResult.Success).data
        assertEquals("00201", refInfo.entityCode)
        assertTrue(refInfo.beneficiaryName.contains("ENDE"))

        // 2. Criar e Executar operação Multicaixa Express no Sandbox
        val mcxCreate = paymentManager.createMulticaixaExpressOperation(
            phoneNumber = "+244 946 110 370",
            amount = 150.0,
            merchantOrService = "Pagamento MCX Express",
            description = "Teste MCX Express"
        )
        assertTrue(mcxCreate is NetworkResult.Success)
        val mcxOp = (mcxCreate as NetworkResult.Success).data
        assertEquals(PaymentType.MULTICAIXA_EXPRESS, mcxOp.type)
        assertEquals(AuthMethod.MCX_EXPRESS, mcxOp.authMethod)
        assertEquals(PaymentStatus.PENDING_AUTHORIZATION, mcxOp.status)

        // Saldo não muda apenas por criar a operação
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // Autorizar e executar
        paymentManager.authorizePaymentOperation(mcxOp.id, AuthMethod.MCX_EXPRESS)
        val mcxConfirm = paymentManager.processAndConfirmPayment(mcxOp.id)
        assertTrue(mcxConfirm is NetworkResult.Success)
        assertEquals(850.0, paymentManager.sandboxBalance.value, 0.001)
    }
}
