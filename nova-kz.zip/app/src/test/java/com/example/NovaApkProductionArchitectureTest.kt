package com.example

import com.example.core.environment.MethodAvailabilityState
import com.example.core.environment.NovaEnvironment
import com.example.core.environment.NovaEnvironmentConfig
import com.example.core.security.NovaLogger
import com.example.core.transaction.TransactionStatusMapper
import com.example.domain.models.PaymentMethod
import com.example.domain.models.PaymentProvider
import com.example.domain.models.PaymentStatus
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class NovaApkProductionArchitectureTest {

    @Before
    fun setUp() {
        NovaEnvironmentConfig.resetToDefaults()
    }

    @After
    fun tearDown() {
        NovaEnvironmentConfig.resetToDefaults()
    }

    @Test
    fun `test NovaEnvironmentConfig provides centralized environment and method states`() {
        assertEquals(NovaEnvironment.SANDBOX, NovaEnvironmentConfig.environment)

        val expressConfig = NovaEnvironmentConfig.getMethodConfig("MULTICAIXA_EXPRESS")
        assertNotNull(expressConfig)
        assertEquals(
            "Disponível para configuração / Homologação",
            expressConfig.statusMessage
        )
        assertEquals(
            MethodAvailabilityState.AVAILABLE_FOR_HOMOLOGATION,
            expressConfig.availabilityState
        )

        val refConfig = NovaEnvironmentConfig.getMethodConfig("REFERENCE_PAYMENT")
        assertNotNull(refConfig)
        assertEquals(
            "Disponível para configuração / Homologação",
            refConfig.statusMessage
        )

        val comingSoon = NovaEnvironmentConfig.getComingSoonMethods()
        val codes = comingSoon.map { it.methodCode }
        assertTrue(codes.contains("UNITEL_MONEY"))
        assertTrue(codes.contains("KWIK"))
        assertTrue(codes.contains("DIRECT_DEBIT"))
        assertTrue(codes.contains("INTERNATIONAL_CARDS"))
        comingSoon.forEach { method ->
            assertEquals("Brevemente", method.statusMessage)
            assertFalse(method.isActive)
        }
    }

    @Test
    fun `test NovaEnvironmentConfig dynamically updates from backend JSON without APK rebuild`() {
        val backendJson = JSONObject().apply {
            put("environment", "PRODUCTION")
            put("methods", JSONArray().apply {
                put(JSONObject().apply {
                    put("method_code", "MULTICAIXA_EXPRESS")
                    put("active", true)
                    put("available", true)
                    put("environment", "PRODUCTION")
                    put("message", "Ativo")
                })
            })
        }

        NovaEnvironmentConfig.applyBackendDynamicConfig(backendJson)
        assertEquals(NovaEnvironment.PRODUCTION, NovaEnvironmentConfig.environment)

        val updatedExpress = NovaEnvironmentConfig.getMethodConfig("MULTICAIXA_EXPRESS")
        assertEquals(MethodAvailabilityState.ACTIVE, updatedExpress.availabilityState)
        assertEquals("Ativo", updatedExpress.statusMessage)
    }

    @Test
    fun `test canonical PaymentStatus and TransactionStatusMapper labels`() {
        assertEquals("Em processamento", TransactionStatusMapper.toDisplayLabel(PaymentStatus.PENDING))
        assertEquals("A processar", TransactionStatusMapper.toDisplayLabel(PaymentStatus.PROCESSING))
        assertEquals("Concluído", TransactionStatusMapper.toDisplayLabel(PaymentStatus.SUCCEEDED))
        assertEquals("Falhou", TransactionStatusMapper.toDisplayLabel(PaymentStatus.FAILED))
        assertEquals("Expirado", TransactionStatusMapper.toDisplayLabel(PaymentStatus.EXPIRED))
        assertEquals("Cancelado", TransactionStatusMapper.toDisplayLabel(PaymentStatus.CANCELLED))
        assertEquals("Reembolsado", TransactionStatusMapper.toDisplayLabel(PaymentStatus.REFUNDED))

        assertEquals(PaymentStatus.SUCCEEDED, PaymentStatus.fromBackendString("SUCCEEDED"))
        assertEquals(PaymentStatus.PENDING, PaymentStatus.fromBackendString("PENDING"))
        assertEquals(PaymentStatus.PROCESSING, PaymentStatus.fromBackendString("PROCESSING"))
        assertEquals(PaymentStatus.EXPIRED, PaymentStatus.fromBackendString("EXPIRED"))
        assertEquals(PaymentStatus.REFUNDED, PaymentStatus.fromBackendString("REFUNDED"))
        assertTrue(PaymentStatus.SUCCEEDED.isSuccessful())
        assertTrue(PaymentStatus.SUCCEEDED.isTerminal())
        assertTrue(PaymentStatus.EXPIRED.isTerminal())
        assertTrue(PaymentStatus.REFUNDED.isTerminal())
    }

    @Test
    fun `test PaymentProvider and PaymentMethod enums`() {
        val providers = PaymentProvider.entries.map { it.name }
        assertTrue(providers.containsAll(listOf("BITPAY", "INTELIZE", "APPYPAY", "PAYPAY", "BANK")))

        val methods = PaymentMethod.entries.map { it.name }
        assertTrue(methods.contains("MULTICAIXA_EXPRESS"))
        assertTrue(methods.contains("REFERENCE_PAYMENT"))
        assertTrue(methods.contains("NOVA_TO_NOVA"))
        assertTrue(methods.contains("IBAN"))
        assertTrue(methods.contains("UNITEL_MONEY"))
        assertTrue(methods.contains("KWIK"))
    }

    @Test
    fun `test NovaLogger redacts sensitive tokens PINs and IBANs`() {
        val rawMessage = """{"access_token":"secret_jwt_123","pin":"1234","iban":"AO06.0040.0000.1234.5678.9012.3"}"""
        val sanitized = NovaLogger.sanitize(rawMessage)
        assertFalse(sanitized.contains("secret_jwt_123"))
        assertFalse(sanitized.contains("\"1234\""))
        assertFalse(sanitized.contains("5678.9012.3"))
        assertTrue(sanitized.contains("[REDACTED]"))
    }
}
