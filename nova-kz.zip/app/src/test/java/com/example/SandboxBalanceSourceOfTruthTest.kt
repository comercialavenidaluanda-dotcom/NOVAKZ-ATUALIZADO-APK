package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.auth.AuthManager
import com.example.data.LocalDataStore
import com.example.data.local.NovaKzDatabase
import com.example.data.repository.PaymentTransactionRepository
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.network.SupabaseEndpoints
import com.example.network.SupabaseRestClient
import com.example.payments.PaymentManager
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

/**
 * Testes obrigatórios de Fonte de Verdade do Saldo Sandbox (Supabase RPC `nova_kz_get_sandbox_balance`).
 *
 * Valida:
 * - TESTE 1: Login -> Consultar saldo no Supabase -> Mostrar exatamente o saldo retornado pelo backend.
 * - TESTE 2: Executar pagamento Sandbox de 100 AOA -> Saldo anterior - 100 AOA recarregado do Supabase.
 * - TESTE 3: Fechar completamente a aplicação e abrir novamente -> Mesmo saldo persistido no Supabase (NÃO volta para 1.000 AOA).
 * - TESTE 4: Limpar cache local do aplicativo e fazer login novamente -> Saldo obtido do Supabase.
 * - TESTE 5: Simular erro da RPC -> Mostrar erro de sincronização (NÃO mostrar 1.000 AOA).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SandboxBalanceSourceOfTruthTest {

    private lateinit var context: Context
    private lateinit var dataStore: LocalDataStore
    private lateinit var inMemoryDb: NovaKzDatabase
    private lateinit var restClient: SupabaseRestClient
    private lateinit var repository: PaymentTransactionRepository
    private lateinit var authManager: AuthManager
    private lateinit var paymentManager: PaymentManager

    // Simula a tabela persistida `bankbot.sandbox_wallets` no Supabase
    private var supabasePersistedWalletBalance: Double = 740.00
    private var simulateRpcError: Boolean = false
    private var simulateUninitializedWallet: Boolean = false
    private val backendOperations = mutableMapOf<String, Double>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        dataStore = LocalDataStore(context)
        dataStore.clearSession()
        dataStore.clearSandboxBalanceCache()

        supabasePersistedWalletBalance = 740.00
        simulateRpcError = false
        simulateUninitializedWallet = false
        backendOperations.clear()

        inMemoryDb = Room.inMemoryDatabaseBuilder(
            context,
            NovaKzDatabase::class.java
        ).allowMainThreadQueries().build()

        restClient = createConfiguredRestClient()
        repository = PaymentTransactionRepository(
            transactionDao = inMemoryDb.paymentTransactionDao(),
            restClient = restClient
        )
        authManager = AuthManager(dataStore, restClient)
        paymentManager = PaymentManager(
            dataStore = dataStore,
            restClient = restClient,
            transactionRepository = repository
        )
    }

    @After
    fun tearDown() {
        inMemoryDb.close()
    }

    private fun createConfiguredRestClient(): SupabaseRestClient {
        return SupabaseRestClient(
            getRefreshToken = { dataStore.refreshToken },
            onTokensRefreshed = { access, refresh, exp -> dataStore.saveSession(access, refresh, exp) },
            getAuthToken = { dataStore.authToken }
        ).apply {
            rpcHandler = { functionName, params ->
                when (functionName) {
                    SupabaseEndpoints.RPC_GET_SANDBOX_BALANCE -> {
                        if (simulateRpcError) {
                            NetworkResult.Error("Falha de comunicação com bankbot.get_my_sandbox_balance", code = 500)
                        } else if (simulateUninitializedWallet) {
                            NetworkResult.Success("null")
                        } else {
                            NetworkResult.Success("""{"ok":true,"balance":$supabasePersistedWalletBalance,"wallet_initialized":true}""")
                        }
                    }
                    SupabaseEndpoints.RPC_CREATE_PAYMENT -> {
                        val opId = "op_" + UUID.randomUUID().toString().take(8)
                        val amount = params.optDouble("p_amount", 0.0)
                        backendOperations[opId] = amount
                        NetworkResult.Success("""{"ok":true,"operation_id":"$opId","status":"PENDING_AUTHORIZATION"}""")
                    }
                    SupabaseEndpoints.RPC_AUTHORIZE_PAYMENT -> {
                        val opId = params.optString("p_operation_id", "")
                        NetworkResult.Success("""{"ok":true,"operation_id":"$opId","status":"AUTHORIZED"}""")
                    }
                    SupabaseEndpoints.RPC_EXECUTE_SANDBOX_PAYMENT -> {
                        val opId = params.optString("p_operation_id", "")
                        val amount = backendOperations[opId] ?: 0.0
                        if (simulateRpcError) {
                            NetworkResult.Error("Erro na execução remota do pagamento", code = 500)
                        } else if (amount > supabasePersistedWalletBalance) {
                            NetworkResult.Error("INSUFFICIENT_FUNDS", code = 400)
                        } else {
                            supabasePersistedWalletBalance -= amount
                            NetworkResult.Success(
                                """{"ok":true,"operation_id":"$opId","status":"COMPLETED","new_balance":$supabasePersistedWalletBalance}"""
                            )
                        }
                    }
                    SupabaseEndpoints.RPC_TRANSITION_PAYMENT -> {
                        NetworkResult.Success("""{"ok":true}""")
                    }
                    else -> NetworkResult.Success("{}")
                }
            }
        }
    }

    @Test
    fun teste1_loginAndLoadBalance_showsExactSupabaseBalance_neverDefaultsTo1000() = runBlocking {
        // Antes de carregar do Supabase, nunca deve ser 1.000,00 AOA
        assertNotEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // Login com sessão autenticada
        dataStore.userId = "usr_supabase_auth_01"
        dataStore.saveSession(accessToken = "jwt_valid_token", newRefreshToken = "refresh_valid_token")

        // Consultar saldo no Supabase (740,00 AOA)
        val result = paymentManager.loadSandboxBalance()
        assertTrue(result is NetworkResult.Success)
        assertEquals(740.00, (result as NetworkResult.Success).data, 0.001)

        // Mostrar exatamente o saldo retornado pelo backend
        assertEquals(740.00, paymentManager.sandboxBalance.value, 0.001)
        assertEquals(740.00, paymentManager.balanceUiState.value.balance ?: -1.0, 0.001)
        assertNull(paymentManager.balanceUiState.value.syncError)
    }

    @Test
    fun teste2_executeSandboxPayment100Aoa_reloadsBalanceFromSupabase() = runBlocking {
        dataStore.userId = "usr_supabase_auth_01"
        dataStore.saveSession(accessToken = "jwt_valid_token", newRefreshToken = "refresh_valid_token")
        paymentManager.loadSandboxBalance()
        assertEquals(740.00, paymentManager.sandboxBalance.value, 0.001)

        // Executar pagamento Sandbox de 100 AOA
        val createRes = paymentManager.createPaymentOperation(
            type = PaymentType.MULTICAIXA_EXPRESS,
            amount = 100.00,
            beneficiary = "Unitel Recarga",
            description = "Pagamento Express 100 AOA",
            authMethod = AuthMethod.MCX_EXPRESS
        )
        assertTrue(createRes is NetworkResult.Success)
        val createdOp = (createRes as NetworkResult.Success).data

        val authRes = paymentManager.authorizePaymentOperation(createdOp.id, AuthMethod.MCX_EXPRESS)
        assertTrue(authRes is NetworkResult.Success)

        val execRes = paymentManager.processAndConfirmPayment(createdOp.id)
        assertTrue(execRes is NetworkResult.Success)
        val confirmedOp = (execRes as NetworkResult.Success).data
        assertEquals(PaymentStatus.CONFIRMED, confirmedOp.status)

        // Esperado: saldo anterior (740 AOA) - 100 AOA = 640 AOA
        assertEquals(640.00, supabasePersistedWalletBalance, 0.001)
        assertEquals(640.00, paymentManager.sandboxBalance.value, 0.001)
        assertEquals(640.00, paymentManager.balanceUiState.value.balance ?: -1.0, 0.001)
    }

    @Test
    fun teste3_closeAndReopenApplication_preservesSupabaseBalance_neverResetsTo1000() = runBlocking {
        dataStore.userId = "usr_supabase_auth_01"
        dataStore.saveSession(accessToken = "jwt_valid_token", newRefreshToken = "refresh_valid_token")
        paymentManager.loadSandboxBalance()

        // Executar pagamento de 100 AOA (740 -> 640 AOA)
        val op = (paymentManager.createPaymentOperation(
            type = PaymentType.REFERENCE_PAYMENT,
            amount = 100.00,
            beneficiary = "ENDE - E.P.",
            description = "Energia",
            reference = "100293849"
        ) as NetworkResult.Success).data
        paymentManager.authorizePaymentOperation(op.id)
        paymentManager.processAndConfirmPayment(op.id)
        assertEquals(640.00, paymentManager.sandboxBalance.value, 0.001)

        // Simular fecho completo da aplicação (novas instâncias de LocalDataStore, RestClient, PaymentManager)
        val reopenedDataStore = LocalDataStore(context)
        val reopenedRestClient = createConfiguredRestClient()
        val reopenedRepository = PaymentTransactionRepository(
            transactionDao = inMemoryDb.paymentTransactionDao(),
            restClient = reopenedRestClient
        )
        val reopenedPaymentManager = PaymentManager(
            dataStore = reopenedDataStore,
            restClient = reopenedRestClient,
            transactionRepository = reopenedRepository
        )

        // Antes mesmo do RPC e após o RPC, o saldo NUNCA pode voltar para 1.000 AOA
        assertNotEquals(1000.0, reopenedPaymentManager.sandboxBalance.value, 0.001)

        // Ao reabrir (onResume / startup), recarrega do Supabase
        val reopenSync = reopenedPaymentManager.loadSandboxBalance()
        assertTrue(reopenSync is NetworkResult.Success)
        assertEquals(640.00, reopenedPaymentManager.sandboxBalance.value, 0.001)
        assertEquals(640.00, reopenedPaymentManager.balanceUiState.value.balance ?: -1.0, 0.001)
    }

    @Test
    fun teste4_clearLocalCacheAndLoginAgain_loadsPersistedBalanceFromSupabase() = runBlocking {
        // Saldo no Supabase é 525,50 AOA
        supabasePersistedWalletBalance = 525.50

        // Limpar completamente o cache local (SharedPreferences + Room)
        dataStore.clearSession()
        dataStore.clearSandboxBalanceCache()
        repository.clearCachedBalance("usr_supabase_auth_01")

        // Confirmar que sem cache local não assume 1.000 AOA
        val freshPaymentManager = PaymentManager(
            dataStore = dataStore,
            restClient = restClient,
            transactionRepository = repository
        )
        assertEquals(0.0, freshPaymentManager.sandboxBalance.value, 0.001)
        assertNotEquals(1000.0, freshPaymentManager.sandboxBalance.value, 0.001)

        // Fazer login novamente e consultar o Supabase
        dataStore.userId = "usr_supabase_auth_01"
        dataStore.saveSession(accessToken = "jwt_new_login_token", newRefreshToken = "refresh_new_token")
        val syncResult = freshPaymentManager.loadSandboxBalance()

        assertTrue(syncResult is NetworkResult.Success)
        assertEquals(525.50, freshPaymentManager.sandboxBalance.value, 0.001)
        assertEquals(525.50, repository.getCachedBalance("usr_supabase_auth_01") ?: -1.0, 0.001)
    }

    @Test
    fun teste5_simulateRpcError_showsSyncErrorAndNeverShows1000Aoa() = runBlocking {
        // Limpar qualquer cache anterior e simular erro na RPC `nova_kz_get_sandbox_balance`
        dataStore.clearSandboxBalanceCache()
        simulateRpcError = true

        val errorTestPaymentManager = PaymentManager(
            dataStore = dataStore,
            restClient = restClient,
            transactionRepository = repository
        )
        dataStore.userId = "usr_supabase_auth_error"
        dataStore.saveSession(accessToken = "jwt_valid_token", newRefreshToken = "refresh_valid_token")

        val result = errorTestPaymentManager.loadSandboxBalance()
        assertTrue("A chamada deve retornar erro quando a RPC falha", result is NetworkResult.Error)

        val uiState = errorTestPaymentManager.balanceUiState.value
        assertFalse(uiState.isLoading)
        assertNotNull("Deve expor erro de sincronização na UI", uiState.syncError)
        assertNull("Não deve haver saldo confirmado quando a RPC falha sem cache", uiState.balance)
        assertNotEquals("NUNCA deve mostrar 1.000 AOA quando a RPC falha", 1000.0, errorTestPaymentManager.sandboxBalance.value, 0.001)
        assertEquals(0.0, errorTestPaymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testFailedPaymentExecution_doesNotAlterBalanceOrConfirmReceipt() = runBlocking {
        dataStore.userId = "usr_supabase_auth_01"
        dataStore.saveSession(accessToken = "jwt_valid_token", newRefreshToken = "refresh_valid_token")
        paymentManager.loadSandboxBalance()
        assertEquals(740.00, paymentManager.sandboxBalance.value, 0.001)

        val createRes = paymentManager.createPaymentOperation(
            type = PaymentType.TRANSFER,
            amount = 100.00,
            beneficiary = "Destinatário Teste",
            description = "Teste falha na execução"
        )
        val createdOp = (createRes as NetworkResult.Success).data
        paymentManager.authorizePaymentOperation(createdOp.id)

        // Simular falha na RPC `nova_kz_execute_sandbox_payment`
        simulateRpcError = true
        val execRes = paymentManager.processAndConfirmPayment(createdOp.id)
        assertTrue(execRes is NetworkResult.Error)

        // Saldo local NÃO pode ser alterado
        assertEquals(740.00, paymentManager.sandboxBalance.value, 0.001)
        // Operação NÃO pode estar como CONFIRMED no histórico
        val opAfterFail = paymentManager.getOperationById(createdOp.id)
        assertNotNull(opAfterFail)
        assertNotEquals(PaymentStatus.CONFIRMED, opAfterFail?.status)
    }
}
