# NOVA KZ — RELATÓRIO DE AUDITORIA E PREPARAÇÃO GOOGLE PLAY

**Aplicação:** NOVA KZ  
**Identificador (applicationId):** `ao.novakz.app`  
**Namespace:** `com.example`  
**VersionCode:** `1`  
**VersionName:** `1.0.0`  
**SDKs:** minSdk `24` | targetSdk `36` | compileSdk `36`  
**Supabase Project Ref:** `earucsaqqtbllnqsxvlb`  
**Data da Auditoria:** 23 de Setembro de 2026  

---

## CONTACTOS OFICIAIS DE SUPORTE
- **E-mail de Suporte:** `ivanioalberto83@gmail.com`
- **WhatsApp / Linha de Apoio:** `+244 946 110 370`
- **Termos e Condições:** `https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-terms`
- **Política de Privacidade:** `https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-privacy`
- **Eliminação de Conta (Web):** `https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-account-deletion`

---

## 1. DATA SAFETY (SEGURANÇA DOS DADOS) — GUIA DO FORMULÁRIO GOOGLE PLAY

### A. Recolha e Segurança Geral
- **A aplicação recolhe ou partilha dados do utilizador?** Sim.
- **Todos os dados recolhidos pelo aplicativo são encriptados em trânsito?** Sim (TLS 1.3 / HTTPS obrigatório em todas as chamadas).
- **Os utilizadores podem solicitar a eliminação dos seus dados?** Sim (Disponível diretamente na aplicação em *Perfil > Segurança > Eliminar Conta NOVA KZ* e na página Web oficial).

### B. Categorias de Dados Recolhidos e Declarados

| Categoria | Dado Específico | Recolhido? | Partilhado? | Finalidade | Obrigatório / Opcional |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Informações Pessoais** | **Nome** | Sim | Não | Funcionalidade da app, personalização da conta e cumprimento regulatório. | Obrigatório no cadastro |
| **Informações Pessoais** | **E-mail** | Sim | Não | Autenticação de conta, segurança, notificações de transação e suporte. | Obrigatório |
| **Informações Pessoais** | **Telefone** | Sim | Não | Autenticação, comunicação de segurança e recuperação de credenciais. | Obrigatório |
| **Informações Pessoais** | **NIF (Identificador Fiscal)** | Sim | Não | Cumprimento de obrigações fiscais e prevenção à fraude (Lei n.º 22/11 de Angola). | Obrigatório no cadastro financeiro |
| **Informações Financeiras** | **Informações de Pagamento / IBAN** | Sim | Não | Iniciação de operações, consulta agregada de contas e histórico. | Obrigatório para transações |
| **Informações Financeiras** | **Histórico de Transações** | Sim | Não | Registo de operações, emissão de recibos e auditoria. | Gerado pelas operações |
| **Saúde e Fitness** | Nenhum | Não | Não | N/A | N/A |
| **Mensagens** | Nenhum | Não | Não | N/A | N/A |
| **Fotografias e Vídeos** | Nenhum | Não | Não | N/A | N/A |
| **Ficheiros e Documentos** | Nenhum | Não | Não | N/A | N/A |
| **Áudio** | Gravações de voz | Sim | Não | Comandos de voz no assistente virtual (processado em tempo real, não guardado permanentemente em servidores). | Opcional |
| **Identificadores de Dispositivo** | Token FCM (Firebase) | Sim | Não | Notificações push de transações, segurança e autorizações. | Necessário para notificações |
| **Dados Biométricos** | **NÃO RECOLHIDOS PELOS SERVIDORES** | Não | Não | A biometria é processada unicamente no hardware seguro do dispositivo Android (TEE). Nenhum dado biométrico é transmitido ou guardado pelo NOVA KZ. | Opcional (ativado pelo utilizador) |

### C. Confirmação de Segurança de Segredos
- **`SUPABASE_SERVICE_ROLE_KEY`:** NÃO presente no código do APK/AAB.
- **Chaves Privadas BitPay:** NÃO presentes.
- **Credenciais Bancárias Administrativas:** NÃO presentes.
- **Acesso à Base de Dados:** Exclusivamente através de `SUPABASE_ANON_KEY` com políticas ativas de **Row Level Security (RLS)** por utilizador autenticado (`auth.uid() = user_id`).

---

## 2. CONTENT RATING (CLASSIFICAÇÃO DE CONTEÚDO / IARC)

| Pergunta do Questionário IARC | Resposta Oficial Recomendada | Justificação Factual |
| :--- | :--- | :--- |
| **Categoria da Aplicação** | Utilidades, Produtividade, Finanças ou Outros | Aplicação financeira e de pagamentos utilitários. |
| **Violência** | Não | Não contém qualquer representação de violência. |
| **Medo / Terror** | Não | Não contém elementos de terror ou susto. |
| **Sexualidade / Nudez** | Não | Não contém conteúdo adulto ou sexual. |
| **Linguagem Imprópria** | Não | Toda a interface utiliza português profissional e respeitoso. |
| **Substâncias Controladas** | Não | Sem referências a drogas, álcool ou tabaco. |
| **Jogos de Azar / Apostas** | Não | O NOVA KZ NÃO é uma aplicação de apostas nem jogos. As funcionalidades Sandbox são simulações técnicas com moeda virtual para testes de pagamentos utilitários, sem apostas ou prémios monetários reais. |
| **Compras Digitais na Aplicação (In-App Purchases)** | Não | Não comercializa bens digitais ou assinaturas in-app da Google Play. |
| **Partilha de Localização Física** | Não | Não transmite nem monitoriza localização física contínua. |
| **Acesso a Menores** | Aplicação não destinada especificamente a crianças | Destinada a utilizadores com idade igual ou superior a 18 anos dotados de capacidade jurídica. |

---

## 3. STORE LISTING (FICHA DA PLAY STORE)

### Nome do Aplicativo
```
NOVA KZ
```

### Descrição Curta (Máximo 80 caracteres)
```
Finanças na tua mão — gestão financeira, pagamentos e serviços num ambiente seguro.
```

### Descrição Completa
```
O NOVA KZ é uma plataforma financeira e ecossistema de pagamentos digitais desenvolvido para proporcionar agilidade, transparência e segurança na gestão do teu dia a dia financeiro em Angola.

Com uma interface moderna, nativa em Jetpack Compose e desenhada sob as diretrizes do Material Design 3, o NOVA KZ coloca o controlo das tuas finanças na palma da tua mão.

PRINCIPAIS FUNCIONALIDADES:

• Gestão Financeira Centralizada: Visualiza as tuas contas bancárias, cartões associados e saldo disponível num painel intuitivo e protegido.
• Pagamentos de Serviços: Realiza pagamentos de energia pré-paga e pós-paga (ENDE), abastecimento de água (EPAL), comunicações móveis e recargas de dados (Unitel, Africell, Movicel), televisão por assinatura (DSTV, Zap) e muito mais.
• Envio e Transferências: Inicia transferências e envios com validação rigorosa de destinatário e referências.
• Comprovativos e Histórico Completo: Acede a recibos digitais instantâneos com código de autorização e rastreabilidade total de todas as tuas movimentações.
• Módulo de Crédito e Poupança: Consulta requisitos e critérios de elegibilidade para crédito pessoal e acompanha as tuas metas de poupança financeira.
• Assistente Virtual Inteligente: Executa ações rápidas e consulta dúvidas através de comandos de texto e voz.

SEGURANÇA E PROTECÇÃO DE DADOS DE NÍVEL BANCÁRIO:

• Autenticação Biométrica: Acesso ultra-rápido e autorização de operações com recurso à tua impressão digital ou reconhecimento facial, processados exclusivamente no chip seguro do teu telemóvel (TEE).
• Bloqueio Automático por Inactividade: Proteção imediata contra acessos indevidos se te ausentares do telemóvel.
• Ocultação Rápida de Saldo: Esconde os teus valores com um simples toque para total privacidade em locais públicos.
• Conformidade Legal Rigorosa: Plataforma alinhada com a Lei n.º 22/11 de Protecção de Dados Pessoais de Angola e normas vigentes de segurança digital.
• Direito ao Esquecimento: Mecanismo transparente para solicitação de eliminação de conta diretamente na aplicação.

NOTA IMPORTANTE SOBRE O AMBIENTE SANDBOX:
A aplicação inclui um ambiente de demonstração e testes (SANDBOX NOVA KZ). O saldo demonstrativo (ex.: 1.000,00 AOA) e as transações de teste efetuadas neste modo destinam-se exclusivamente à experimentação de usabilidade e fluxos técnicos, sendo totalmente virtuais e não correspondendo a qualquer movimentação de dinheiro real ou débito em contas bancárias reais.

CANAIS OFICIAIS DE SUPORTE:
E-mail: ivanioalberto83@gmail.com
WhatsApp / Linha de Apoio: +244 946 110 370
Localização: Luanda, República de Angola

DOCUMENTOS LEGAIS:
Termos e Condições: https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-terms
Política de Privacidade: https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-privacy
```

### Checklist de Recursos Gráficos
- [ ] **Ícone da Aplicação:** 512 x 512 px (PNG 32-bit com transparência).
- [ ] **Gráfico de Funcionalidades (Feature Graphic):** 1024 x 500 px (JPEG ou PNG 24-bit).
- [ ] **Screenshots para Telemóvel:** Mínimo 4 capturas de ecrã (1080 x 2400 px sugerido), ilustrando:
  1. Ecrã de Boas-Vindas e Autenticação com Biometria.
  2. Dashboard Principal (Overview) com visualização de Saldo e Ações Rápidas.
  3. Ecrã de Pagamento de Serviços com autorização segura.
  4. Recibo Digital de Operação e Histórico de Transações.
  5. Ecrã de Termos & Privacidade e Segurança.
- [ ] **Categoria:** Finanças (Finance).
- [ ] **Tags:** Finanças Pessoais, Pagamentos, Gestão Financeira.

---

## 4. APP ACCESS (INSTRUÇÕES PARA O REVISOR DO GOOGLE PLAY)

Na secção **"Acesso a aplicações" (App Access)** da Google Play Console, selecionar **"Todas ou algumas das funcionalidades estão restritas"** e fornecer as seguintes instruções:

### Credenciais e Instruções de Acesso para a Revisão
1. **Nome de Acesso:** Conta de Demonstração / Revisor Google Play
2. **E-mail de Teste:** `comercialavenidaluanda@gmail.com`
3. **PIN de Acesso Pré-configurado:** `1234`
4. **Instruções Detalhadas para o Revisor:**
   - **Passo 1 (Abertura):** Ao iniciar o aplicativo pela primeira vez, será apresentado o ecrã de início de sessão.
   - **Passo 2 (Autenticação):** Insira o e-mail de teste `comercialavenidaluanda@gmail.com` e o PIN `1234`. Clique em *"Entrar no NOVA KZ"*.
   - **Passo 3 (Termos e Condições):** Caso seja a primeira abertura, o ecrã obrigatório de aceitação legal surgirá. Marque ambas as caixas de seleção (*"Li e aceito os Termos e Condições"* e *"Li e aceito a Política de Privacidade"*) e prima *"ACEITAR E CONTINUAR"*. A aceitação persistirá para todos os lançamentos futuros.
   - **Passo 4 (Dashboard):** O revisor terá acesso ao saldo inicial do ambiente de testes Sandbox de **1.000,00 AOA**.
   - **Passo 5 (Privacidade do Saldo):** Toque no ícone do olho junto ao saldo para alternar entre visível e oculto.
   - **Passo 6 (Operação Sandbox):** Clique em *"Pagar"*, selecione um serviço (ex.: *ENDE - E.P.*), preencha os dados e prima *"Continuar"*. No ecrã de autorização, valide a operação. Após a confirmação, o saldo Sandbox será atualizado de 1.000,00 AOA para 800,00 AOA e o recibo digital será exibido.
   - **Passo 7 (Histórico):** Toque no separador *"Histórico"* na barra inferior para verificar o comprovativo da operação.
   - **Passo 8 (Segurança e Biometria):** Aceda ao separador *"Perfil"* e escolha *"Segurança"*. Aqui pode testar o bloqueio manual da aplicação e a ativação biométrica.
   - **Passo 9 (Eliminação de Conta):** Aceda a *Perfil > Segurança > Eliminar Conta NOVA KZ* (ou *Perfil > Eliminar Conta*). O ecrã de aviso e o botão de solicitação com a confirmação estão totalmente operacionais.
   - **Passo 10 (Contacto de Suporte):** Para qualquer dúvida durante a revisão técnica, utilize o e-mail `ivanioalberto83@gmail.com` ou WhatsApp `+244 946 110 370`.
