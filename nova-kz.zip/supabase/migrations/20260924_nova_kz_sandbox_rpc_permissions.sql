-- ==============================================================================
-- NOVA KZ — SQL MIGRATION: PUBLIC RPC PERMISSIONS & EXECUTE RIGHTS
-- Target database: Supabase (earucsaqqtbllnqsxvlb)
-- Date: 2026-09-24
-- Purpose: Ensure PostgREST / anon / authenticated roles can execute public RPCs
-- ==============================================================================

-- 1. Grant execute on public RPC functions
DO $$
BEGIN
    -- Grant execute on sandbox balance RPC if exists
    IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'nova_kz_get_sandbox_balance') THEN
        GRANT EXECUTE ON FUNCTION public.nova_kz_get_sandbox_balance() TO anon, authenticated, service_role;
    END IF;

    -- Grant execute on list my payment operations
    IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'nova_kz_list_my_payment_operations') THEN
        GRANT EXECUTE ON FUNCTION public.nova_kz_list_my_payment_operations() TO anon, authenticated, service_role;
    END IF;

    -- Grant execute on list bank accounts
    IF EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'nova_kz_list_bank_accounts') THEN
        GRANT EXECUTE ON FUNCTION public.nova_kz_list_bank_accounts() TO anon, authenticated, service_role;
    END IF;
END $$;

-- 2. Grant execute on payment operations RPCs (polymorphic / all signatures)
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO anon, authenticated;
