-- ==============================================================================
-- NOVA KZ — SQL MIGRATION: LEGAL ACCEPTANCES TABLE & RLS POLICIES
-- Target database: Supabase (earucsaqqtbllnqsxvlb)
-- Date: 2026-09-23
-- Purpose: Store audit trail of legal terms and privacy policy acceptances
-- ==============================================================================

-- 1. Create table public.nova_kz_legal_acceptances
CREATE TABLE IF NOT EXISTS public.nova_kz_legal_acceptances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    terms_version TEXT NOT NULL,
    privacy_version TEXT NOT NULL,
    accepted_terms BOOLEAN NOT NULL DEFAULT FALSE,
    accepted_privacy BOOLEAN NOT NULL DEFAULT FALSE,
    accepted_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. Indexes for high performance and integrity
CREATE INDEX IF NOT EXISTS idx_nova_kz_legal_acceptances_user 
    ON public.nova_kz_legal_acceptances(user_id, accepted_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS idx_nova_kz_legal_acceptances_unique_version
    ON public.nova_kz_legal_acceptances(user_id, terms_version, privacy_version);

-- 3. Enable Row Level Security (RLS)
ALTER TABLE public.nova_kz_legal_acceptances ENABLE ROW LEVEL SECURITY;

-- 4. RLS Policies
-- Policy: Allow users to view their own legal acceptance history
CREATE POLICY "nova_kz_legal_acceptances_select_own" 
    ON public.nova_kz_legal_acceptances
    FOR SELECT
    USING (
        auth.uid()::text = user_id 
        OR (current_setting('request.jwt.claims', true)::jsonb->>'sub') = user_id
        OR auth.role() = 'anon'
    );

-- Policy: Allow users to insert their acceptance record
CREATE POLICY "nova_kz_legal_acceptances_insert_own" 
    ON public.nova_kz_legal_acceptances
    FOR INSERT
    WITH CHECK (
        accepted_terms = true 
        AND accepted_privacy = true
    );

-- Policy: Block updates and deletions to preserve immutable audit trail
CREATE POLICY "nova_kz_legal_acceptances_no_update" 
    ON public.nova_kz_legal_acceptances
    FOR UPDATE
    USING (false);

CREATE POLICY "nova_kz_legal_acceptances_no_delete" 
    ON public.nova_kz_legal_acceptances
    FOR DELETE
    USING (false);

-- 5. Trigger for updated_at
CREATE OR REPLACE FUNCTION public.set_current_timestamp_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_nova_kz_legal_acceptances_updated_at ON public.nova_kz_legal_acceptances;
CREATE TRIGGER trigger_nova_kz_legal_acceptances_updated_at
    BEFORE UPDATE ON public.nova_kz_legal_acceptances
    FOR EACH ROW
    EXECUTE FUNCTION public.set_current_timestamp_updated_at();

COMMENT ON TABLE public.nova_kz_legal_acceptances IS 'Audit log of user acceptances of NOVA KZ Terms and Conditions & Privacy Policy.';
